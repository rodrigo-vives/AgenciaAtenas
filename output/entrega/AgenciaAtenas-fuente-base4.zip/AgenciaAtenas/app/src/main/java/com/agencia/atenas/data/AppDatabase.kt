package com.agencia.atenas.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * Room crea las tablas normalizadas a partir de las clases Entity.
 * No mantenemos conversiones desde estructuras antiguas en este proyecto de prueba.
 * Conservamos la versión 4: las instalaciones que ya tienen esta estructura
 * pueden seguir usando sus datos. Una instalación con una versión anterior
 * necesita borrar el almacenamiento de la aplicación o reinstalarla.
 * No borramos datos automáticamente al encontrar una versión incompatible.
 */
@Database(
    entities = [UsuarioEntity::class, GestionOportunidadEntity::class,
        OrganizacionEntity::class, ContactoEntity::class, SeguimientoEntity::class,
        OportunidadContactoEntity::class],
    version = 4,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun usuarioDao(): UsuarioDao
    abstract fun oportunidadDao(): OportunidadDao
    abstract fun catalogoDao(): CatalogoDao

    companion object {
        @Volatile private var instancia: AppDatabase? = null

        fun obtenerBaseDeDatos(context: Context): AppDatabase {
            // Se revisa de nuevo dentro del bloqueo: otra llamada puede haber creado la base.
            return instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "agencia_atenas.db"
                )
                    .build().also { instancia = it }
            }
        }
    }
}
