# Animaciones e interacción con fotografías

Se aplicaron tres interacciones en el detalle, siguiendo AnimatedVisibility y Crossfade del PPT 06-Recursos.

1. Al cargar una fotografía, AnimatedVisibility combina fadeIn y expandVertically para mostrar la vista previa suavemente. También sucede al volver a entrar en un detalle y cargar sus fotos guardadas.
2. Al tocar una vista previa, se abre una ampliación con AnimatedVisibility. El botón Cerrar, Atrás o tocar fuera solicita el cierre animado. MutableTransitionState permite esperar a que termine la salida antes de retirar el diálogo. La ampliación reutiliza el bitmap de vista previa: no modifica el archivo original ni ofrece zoom por gestos.
3. Crossfade cambia el mensaje entre ninguna, una o varias fotografías guardadas. Se basa en la cantidad real; cancelar la cámara no suma fotos.

Las rutas se usan como claves estables de composición para que añadir una captura no reinicie las vistas previas anteriores. Los efectos se configuraron más lentos para que se distingan durante la presentación y no bloquean el guardado ni realizan cambios en Room.

El archivo ui/RecursosOportunidad.kt incluye comentarios ANIMACIÓN 1, 2 y 3 y explica cómo se relacionan el estado, la carga de imágenes y las transiciones. Se usan colores y tipografía del tema.

## Comprobación manual

- Entrar en una oportunidad sin fotos: se muestra el mensaje de lista vacía.
- Capturar y confirmar una foto: aparece suavemente y cambia el contador a una.
- Capturar una segunda: se conservan ambas y el contador pasa a dos.
- Cancelar una captura: no cambia la cantidad.
- Tocar una foto: se abre grande, con proporciones conservadas y botón Cerrar.
- Cerrar mediante el botón, mediante Atrás y tocando fuera del diálogo; el detalle sigue disponible.
- Repetir con otra foto y con fotos verticales/horizontales.

Estas modificaciones cubren las tres interacciones propuestas. La revisión visual del resto de pantallas sigue pendiente.

Ajuste de ampliación: el diálogo reserva su tamaño desde el inicio y anima solo la opacidad. Se retiró la expansión vertical de la ampliación porque producía cambios de tamaño visibles en la imagen. La aparición de las vistas previas mantiene su expansión.

Ajuste para la defensa: aparición de fotos de 900 ms, apertura de ampliación de 800 ms, cierre de 650 ms y transición del contador de 1000 ms. La ampliación conserva tamaño fijo; no se añadieron rebotes ni cambios de escala.
