# Filtros y revisión visual

## Cómo se usan

En Oportunidades, pulsar Mostrar filtros. Todos los criterios se combinan: un registro debe cumplir cada filtro activo. Limpiar filtros y búsqueda devuelve el listado completo que permite el rol. Ocultar el panel no desactiva los filtros; su cantidad queda visible.

- Nombre: coincidencia parcial sin distinguir mayúsculas y quitando espacios de los extremos de la búsqueda.
- Estado: se puede elegir cualquiera de los diez estados del modelo, no solo Confirmados/En espera.
- Prioridad y tipo: selección exacta; los tipos se obtienen de oportunidades visibles.
- Ubicación: busca parcialmente en comuna, región o ubicación general, sin distinguir mayúsculas. No elimina tildes: escribir Ñuñoa o una parte coincidente.
- Organización y responsable: se comparan IDs, evitando confundir nombres repetidos. Las opciones provienen de registros visibles.
- Responsable: solo lo ofrece la UI al supervisor y el ViewModel comprueba ese rol; la autorización real del listado sigue en Repository.
- Desde/Hasta: fechas DD/MM/AAAA aplicadas a la fecha de inicio del evento. Incluye ambos extremos y admite un solo límite. Una fecha inválida o rango invertido muestra errores y suspende resultados hasta corregir.

## Cómo funciona y por qué

ListaUiState contiene datos y filtros, deriva erroresFechas y gestionesFiltradas de una misma instantánea. No se guarda una segunda lista ni se agregan columnas a Room. Primero valida fechas visibles, luego las convierte a ISO para compararlas en orden. Cuando no hay rango no excluye registros antiguos sin fecha; con rango exige una fecha válida.

ListaViewModel publica copias del estado al recibir cada cambio. La limpieza conserva la lista obtenida y los estados de carga/error. ListaScreen observa con collectAsStateWithLifecycle, dibuja controles y resultados en una sola LazyColumn, y usa la clave id de cada oportunidad. Esto permite desplazarse hasta filtros y resultados con teclado y en pantallas pequeñas.

Los filtros son una selección temporal del destino; no se guardan entre cierres de proceso. No amplían la lista autorizada por Repository.

## Ajustes visuales aplicados

- Inicio sin enlace Volver que cerraba sesión de forma confusa; se conserva el botón explícito Cerrar sesión.
- Resumen de oportunidades y atrasos en una tarjeta con colores del tema.
- Separadores y encabezados para datos comerciales, evento, organización/contacto y observaciones en Detalle.
- Márgenes dentro de tarjetas de organizaciones/contactos.
- Ícono de error junto al mensaje y el borde del campo compartido Campo.
- Listado con título, contador de resultados, filtros plegables y limpieza visible aunque el panel esté cerrado.

Estos cambios usan MaterialTheme. La legibilidad real con modo oscuro, letra ampliada y teclado requiere el recorrido manual del dispositivo; no se afirma que se inspeccionó visualmente una pantalla que no se pudo abrir.

## Archivos a estudiar

- ListaUiState.kt: criterios y combinación con AND, fechas e IDs.
- ListaViewModel.kt: eventos de selección y limpieza.
- ListaScreen.kt: opciones derivadas, panel y resultados desplazables.
- ComponentesFormulario.kt y drawable/ic_error_formulario.xml: error accesible y visibilidad opcional de Volver.
- InicioScreen.kt, DetalleScreen.kt y CatalogoScreen.kt: jerarquía y espacios.
- ListaUiStateTest.kt: combinación de todos los criterios, IDs con nombres iguales, extremos del rango, fechas inválidas, ubicación y limpieza.
