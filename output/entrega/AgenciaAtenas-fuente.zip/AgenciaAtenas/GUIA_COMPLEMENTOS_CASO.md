# Complementos del caso y checklist

Versión de base 5, 18/10/2026. El equipo eligió expresamente no utilizar migraciones y probar en una instalación limpia. Para conservar la instalación antigua, usar otro emulador. No se configuró borrado automático ni se cambiaron versiones de Gradle o dependencias.

## Qué se añadió

### Perfil

Inicio -> Mi perfil. Muestra nombre ficticio de la cuenta, usuario, ID, rol, estado y cantidad visible. PerfilViewModel observa la fila de usuarios y las oportunidades autorizadas. La pantalla no muestra contraseña ni hash. No se añadieron los campos opcionales de área/sucursal ni edición de perfil.

### Organización completa

En Organizaciones se pueden registrar nombre, tipo, rubro, comuna, región, sitio web, público asociado y observaciones. Los datos desconocidos pueden quedar vacíos. El sitio web exige http:// o https:// y host válido; no intenta abrir ni consultar un sitio real.

Los eventos relacionados y su historial no se copian dentro de la organización: se consultan por relación y se abren con Ver eventos e historial. Los datos del contacto que el PDF presenta como opcionales conservan el alcance original: nombre, organización, cargo, área, correo, teléfono y medio.

### Historial por contacto

Contactos -> Ver historial de contacto. Seguimiento guarda ahora contactoId, que referencia a Contacto con clave foránea. Al registrar una gestión se toma el contacto principal que tiene la oportunidad en ese momento. Cambiar después ese contacto no cambia las gestiones anteriores.

La consulta enlaza seguimiento, oportunidad y autor, y Repository intersecta con las oportunidades que el usuario puede consultar actualmente. La reasignación retira ese historial al ejecutivo anterior; el supervisor conserva la visión global. Si una gestión se hizo sin contacto conocido, queda null y solo se ve en el historial de oportunidad: no se inventa una persona.

El historial por organización corresponde a sus oportunidades relacionadas actualmente. Si se cambia la organización de una oportunidad, esta pasa a consultarse en la nueva organización. El contacto histórico de cada gestión conserva su propio vínculo.

### Resultado de activación

Detalle -> Registrar resultado de activación, disponible para participaciones confirmadas, realizadas o cerradas. Fecha de realización y evaluación son obligatorias; asistentes, contactos generados, interesados e inscripciones son enteros no negativos opcionales. También se guardan observaciones y aprendizajes. Fecha futura o imposible se rechaza.

ResultadoActivacionEntity complementa al seguimiento mediante seguimientoId como PK y FK. Autor, oportunidad, evaluación y observaciones ya están en Seguimiento: no se duplican en Resultado. Desconocido se representa por null, que se distingue de cero.

OportunidadRepository.guardarResultado realiza en una transacción: registrar la gestión, insertar sus indicadores y, si estaba confirmada, cambiar a realizada usando las reglas existentes. No permite saltar de identificada a realizada ni permite al ejecutivo confirmar su propia participación. Otro registro de resultado agrega una nueva entrada histórica, no sobrescribe el anterior.

El detalle muestra los resultados y el historial deja constancia de su autor/fecha. Los indicadores de p. 11 son complementarios en el PDF; se incorporaron para disponer de un recorrido explícito de registro de resultado, que sí aparece en los criterios del caso.

### Oportunidades sin seguimiento

Inicio muestra una sección aparte. Se considera que existe seguimiento cuando hay al menos una gestión comercial; Asignación y Cambio de estado son auditoría automática y no sustituyen una llamada/reunión/respuesta. Se excluyen oportunidades descartadas, realizadas y cerradas.

### Mensajes e ícono

MensajeOperacion recibe mensaje y esError explícitos del ViewModel. No analiza palabras para adivinar éxito/error. Usa pares de colores semánticos y texto explicativo. El ícono de aplicación representa un maletín y una gestión completada, con versión adaptativa y alternativa vectorial para API 24/25.

## Modelo de datos actual

Siete tablas: usuarios, organizaciones, contactos, gestiones_oportunidad, oportunidad_contacto, seguimientos y resultados_activacion.

- Usuario 1:N Oportunidad como responsable actual.
- Usuario 1:N Seguimiento como autor histórico.
- Organización 1:N Contacto y 1:N Oportunidad.
- Oportunidad 0:1 OportunidadContacto, que vincula su contacto principal actual.
- Oportunidad 1:N Seguimiento.
- Contacto 1:N Seguimiento mediante contactoId opcional, independiente del principal actual.
- Seguimiento 0:1 ResultadoActivacion mediante PK/FK compartida.
- Seguimiento puede resolver una próxima acción de otra gestión mediante resueltaPorId.

Las fotografías conservan su carpeta filesDir/evidencias/ID; no son una tabla de bitmaps. Ninguna nueva columna obliga a escribir información desconocida para poder registrar una oportunidad.

## Archivos principales

- OrganizacionEntity, SeguimientoEntity, ResultadoActivacionEntity y AppDatabase: esquema 5.
- CatalogoDao y OportunidadRepository: resultados, historial por contacto/organización y avisos sin gestión.
- CatalogoUiState/ViewModel/Screen y ValidarCatalogo: datos de organización y validación.
- PerfilScreen/ViewModel: perfil consultable.
- HistorialCatalogoScreen/ViewModel: eventos y gestiones con alcance por usuario.
- ResultadoScreen/ViewModel/UiState y ValidarResultado: formulario, reglas y guardado del resultado.
- MensajeOperacion y theme/Color: presentación consistente de operaciones.
- Navegacion: destinos adicionales conectados mediante callbacks e IDs.
- CumplimientoCasoRoomTest: pruebas reales de relaciones, permisos, archivos y resultados.

## Recorrido para la defensa

1. En un emulador limpio entrar con admin/1234 y abrir Mi perfil.
2. Registrar organización y dos contactos ficticios A/B.
3. Crear oportunidad asignada con contacto A y registrar una llamada.
4. Editar oportunidad para elegir B. Abrir historial de A: la llamada debe seguir en A; B no debe heredar esa llamada.
5. Reasignar la oportunidad y comprobar el alcance del historial con ambos ejecutivos.
6. Como supervisor confirmar la participación. Como ejecutivo responsable registrar resultado con fecha de hoy, evaluación y un indicador; dejar otro vacío.
7. Revisar el resultado en detalle: el vacío sigue desconocido, la oportunidad queda realizada y el historial conserva autor y cambio de estado.
8. Crear otra oportunidad sin llamada: debe figurar sin seguimiento. Registrar una gestión y comprobar que sale de esa sección.
9. Repetir cámara, animaciones y Calendar. Guardar el evento desde la aplicación Calendar configurada; nuestra app solo abre su editor.

La fuente de entrega no incluye datos de los emuladores. Omar Martínez y Rodrigo Vivez deben completar sección, repositorio y participación real de ambos; AVA y defensa requieren su intervención.

## Resultado verificado

41 pruebas unitarias y 11 instrumentales aprobadas; Lint sin errores, 14 advertencias. Se comprobó el ingreso admin desde base limpia y el perfil con tema oscuro/letra ampliada. Ver CUMPLIMIENTO_REQUISITOS.md para estados por criterio y condiciones externas.

## Última pasada de lectura

- PerfilUiState, HistorialCatalogoUiState y EvidenciaUiState tienen archivos propios, como los formularios originales.
- El título del historial se obtiene mediante CatalogoRepository.obtenerNombre; el ViewModel no consulta el DAO.
- El perfil también observa su cuenta mediante UsuarioRepository, manteniendo UI -> ViewModel -> Repository -> DAO.
- El filtrado de historial se presenta en variables separadas: IDs históricos, relación actual, IDs autorizados y lista visible.
- ResultadoViewModel explica la instantánea del borrador, validación, bloqueo de doble guardado, éxito y conservación tras un fallo.
- guardarResultado explica los tres pasos de su transacción y por qué no duplica datos.

Esta revisión no cambió tablas, versión de base ni funciones de usuario. Se mantiene base 5 e instalación limpia para quienes vengan de base 4.
