> Actualización base 5 (18/10/2026): para el estado vigente consultar CUMPLIMIENTO_REQUISITOS.md y GUIA_COMPLEMENTOS_CASO.md. Este documento conserva la revisión anterior y puede mencionar limitaciones ya resueltas.

# Revisión y preparación de entrega

Fecha de revisión actualizada: 18/10/2026. Ver también REVISION_GENERAL_EQUIPO.md. Referencias: checklist del profesor y Caso DSY1105_003D de gestión móvil de oportunidades y activaciones corporativas. Este informe distingue implementación, prueba automatizada y comprobación manual pendiente.

## Evidencia automatizada

- assembleDebug: correcto; se generó el APK.
- testDebugUnitTest: 36 pruebas, cero fallos y cero errores.
- compileDebugAndroidTestKotlin: correcto. Esto demuestra compilación, NO ejecución de las pruebas de Room en Android.
- ADB no detectó dispositivos. No se ejecutaron connectedDebugAndroidTest ni interacciones de UI desde esta revisión.
- lintDebug: correcto, sin errores y con 14 advertencias de mantenimiento (ExifInterface de plataforma, etiquetas, versiones disponibles y recursos sin uso). No se cambiaron dependencias ni Gradle para silenciarlas.

Las pruebas nuevas comprueban combinación de filtros, organizaciones con nombres iguales/IDs distintos, responsables, límites de fechas, fechas imposibles/rangos invertidos, ubicación y limpieza. Las anteriores cubren validaciones, permisos de estados, avisos de eventos, próximos seguimientos y conversión a calendario.

## Checklist de evaluación

| Grupo | Implementación y evidencia | Comprobación que queda |
| --- | --- | --- |
| Usuarios y permisos | Cuatro cuentas en Room, dos roles, alcance por responsable, autorización en Repository, asignación y transiciones | Repetir recorrido manual con las cuatro cuentas; ejecutar pruebas instrumentales |
| Pantallas | Nueve destinos lógicos conectados; crear/editar comparten formulario y dos catálogos comparten componente | Recorrido completo de navegación y Atrás |
| Búsqueda y filtros | Nombre, todos los estados, prioridad, tipo, ubicación, organización, responsable y fechas combinables | Probar controles y teclado en pantalla pequeña |
| Datos y arquitectura | Seis tablas con PK/FK, JOIN, MVVM, StateFlow, historial y transacciones | Ejecutar pruebas de Room; persistencia manual entre cierres |
| Validaciones | Obligatorios, formatos, límites, fechas/costos, mensajes y nuevo ícono en Campo; preserva borrador al fallar | Probar errores visibles en cada formulario |
| Pendientes y alertas | Próximos eventos, pendientes, atrasados, sin contacto y sin respuesta; resolución explícita | Comprobar cambio de día y reasignación en el dispositivo |
| Cámara | Captura, cancelación, archivos persistentes por ID, vista previa y ampliación | El usuario confirmó captura; repetir cancelación/rotación/persistencia |
| Calendario | ACTION_INSERT con ubicación, fecha/hora y día completo; cancelación externa | Falta guardar y localizar un evento; Calendar pidió cuenta en el emulador |
| Animaciones | Tres interacciones con AnimatedVisibility y Crossfade; tiempos visibles para defensa | Usuario probó y pidió ajustes; repetir versión final |
| Apariencia | Material 3, tema, colores semánticos, secciones, panel plegable y desplazamiento con teclado | Inspección manual en claro/oscuro, letra ampliada y pantallas pequeñas |
| GitHub y entrega | README y documentación preparados | No hay .git en esta copia; completar nombres y commits reales de ambos, subir a AVA |
| Bonus ícono | Ícono actual del proyecto | No se diseñó un ícono personalizado |

No se marca toda la checklist como aprobada solo porque compiló.

## Revisión adicional del PDF

- Filtros por fecha, estado, tipo, ubicación y organización (p. 14) y prioridad/responsable (p. 18): implementados.
- Perfil (p. 17): se muestra usuario y rol en Inicio; no existe edición de perfil ni los datos opcionales de área/sucursal.
- Historial de oportunidades: implementado por ID, incluyendo seguimiento, cambios de estado y asignación.
- Historial de contacto (p. 17): parcial. El contacto está vinculado a la oportunidad y se puede consultar su información, pero no hay vista independiente por contacto ni vínculo histórico de cada seguimiento con el contacto que existía al momento. Cambiar el contacto principal no crea una versión histórica.
- Resultado de activación (p. 14): se puede registrar con una gestión y su resultado/observaciones. No hay formulario específico de resultados. Los indicadores de contactos/inscripciones/evaluación de p. 11 se presentan como aspectos a validar, no se inventaron como requisitos ya cumplidos.
- Eventos sin seguimiento: los avisos actuales cubren tareas programadas y oportunidades sin contacto; no equivalen exactamente a identificar todas las oportunidades sin ninguna gestión histórica.
- Integraciones productivas, correo real, mapas y notificaciones del sistema: no añadidos; el caso admite avisos internos y el calendario se implementó por exigencia de la checklist.

Estas diferencias deben considerarse al defender el alcance. No se modificó el esquema de datos para inventar un módulo nuevo durante el cierre de filtros.

## Recorrido manual de aceptación

Usar información ficticia y una instalación de prueba distinta si se desean conservar los datos actuales. Cada integrante debe repetirlo.

1. Entrar con admin/1234 y con ejecutivo1/2/3, probar contraseña incorrecta y cerrar sesión. Atrás no debe restaurar la sesión anterior.
2. Crear dos organizaciones ficticias, luego un contacto asociado a una de ellas. Probar nombre vacío, correo/teléfono inválidos y longitudes. Confirmar que no se pierde el borrador.
3. Como ejecutivo1 crear tres oportunidades de tipo/prioridad/fecha distintos, una con organización/contacto y otra sin esos datos. Fechas relativas al día del dispositivo. Probar costos negativos, fecha imposible y término anterior al inicio.
4. Volver a Inicio/Lista/Detalle y comprobar que aparecen los datos. Cerrar completamente y reabrir para confirmar persistencia.
5. En Lista combinar nombre + estado + prioridad + tipo + ubicación + organización + rango. Corregir rango invertido; probar un solo extremo y días exactos. Limpiar debe recuperar todos los registros visibles.
6. Como admin filtrar por ejecutivo1. Reasignar una oportunidad a ejecutivo2 y comprobar que desaparece de ejecutivo1 y aparece a ejecutivo2. Ejecutivo3 no debe verla.
7. Intentar confirmar/descartar como ejecutivo: no debe ofrecerse ni autorizarse. Como supervisor realizar una transición permitida y revisar que queda en historial.
8. Registrar una llamada con resultado y próxima acción para ayer, hoy y mañana. Revisar atrasado/vence hoy/programada. Completar desde Inicio y comprobar historial y retirada del aviso. Si se programa otra tarea, solo la nueva continúa abierta.
9. Capturar dos fotos, cancelar otra y abrir una en grande. Cerrar por botón y Atrás. Rotar durante la captura. Reabrir la app y comprobar que siguen asociadas a su oportunidad.
10. Exportar evento con horario a Calendar, revisar datos, guardar y localizarlo. Repetir con día completo. Cancelar otro intento. Si no hay Calendar o pide cuenta, registrar esa condición y completar la prueba en un dispositivo configurado.
11. Comprobar las tres animaciones y que no impiden usar botones.
12. Repetir pantallas en tema oscuro, con fuente grande, orientación y teclado abierto. Comprobar que el final de los formularios y filtros es alcanzable.

Registrar cada prueba como Aprobada/Fallida con dispositivo, fecha, quién la hizo y captura si corresponde. Esta lista es una pauta para ejecutar; no una declaración de que se ejecutó.

## Antes de entregar

- Completar integrantes/sección en README.
- Resolver y documentar los alcances parciales del PDF con el compañero/profesor.
- Ejecutar pruebas instrumentales con dispositivo: gradlew.bat :app:connectedDebugAndroidTest.
- Completar el guardado real en calendario y la revisión visual.
- Incorporar el código al repositorio compartido y realizar commits propios de ambos sin inventar historial.
- Abrir el ZIP fuente en una carpeta nueva, sincronizar y probar en una instalación limpia.
- Confirmar instrucciones de formato/nombre y subir al AVA. No se hizo un envío automático.

El ZIP fuente preparado excluye cachés, builds, local.properties, .idea, archivos temporales y .git. Incluye fuentes, recursos, wrapper/configuración Gradle y guías Markdown. Los PDF anteriores no se incluyen para evitar presentar como vigente documentación histórica.
