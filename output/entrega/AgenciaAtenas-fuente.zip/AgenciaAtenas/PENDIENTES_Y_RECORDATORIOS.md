> Actualización: se retiraron las migraciones históricas para simplificar la entrega. Room crea directamente las tablas actuales. Se mantiene la versión 4 para conservar las instalaciones que ya usan esa estructura. Solo las bases anteriores necesitan borrar datos o reinstalar la aplicación. Las explicaciones de migraciones que aparecen más abajo son históricas y ya no describen código vigente.

# Pendientes, atrasados y recordatorios internos

## Qué se implementó

Inicio muestra acciones programadas sin resolver separadas en dos grupos: gestiones atrasadas y seguimientos pendientes. Dentro de pendientes se distingue lo que vence hoy. También muestra próximos eventos, oportunidades sin contacto asociado y propuestas registradas sin respuesta.

Son avisos dentro de la aplicación. No se envían notificaciones del sistema, correos ni mensajes externos. Cámara y calendario siguen pendientes para el punto 3.

## Cómo probarlo

1. Abrir una oportunidad activa y entrar en Seguimiento e historial.
2. Registrar acción realizada y resultado, por ejemplo Llamada inicial / No respondió.
3. Completar Próxima acción con Volver a llamar y una fecha de ayer. Guardar.
4. Volver a Inicio: debe aparecer en Gestiones atrasadas.
5. Repetir con una fecha de hoy y otra futura: aparecen en Pendientes, con su etiqueta.
6. Pulsar Registrar resultado en una tarjeta de Inicio. Se abre esa oportunidad con la acción programada precargada.
7. Escribir el resultado y pulsar Completar acción y guardar resultado. No basta pulsar el botón con un resultado vacío.
8. Volver a Inicio: la acción completada ya no debe aparecer. Si se programó otra próxima acción al guardar, esa nueva sí aparece.
9. Revisar el historial: permanece el registro original y aparece la gestión que lo completó. En el original se muestran fecha, autor y resultado de resolución.
10. Como supervisor, reasignar la oportunidad a otro ejecutivo y comprobar que sus acciones abiertas aparecen al responsable actual y dejan de aparecer al anterior.

Usar fechas relativas al día del dispositivo. Ayer significa atrasada, hoy vence hoy y mañana es pendiente futura. Los campos visibles siguen usando DD/MM/AAAA.

## Regla de clasificación

| Condición | Presentación |
| --- | --- |
| Fecha anterior a hoy y tarea abierta | Gestiones atrasadas |
| Fecha de hoy y tarea abierta | Pendientes / Vence hoy |
| Fecha futura y tarea abierta | Pendientes / Programada |
| Tarea completada | Solo historial; no vuelve a recordar |
| Sin próxima acción o sin fecha | No es tarea programada |
| Fecha heredada inválida | No se clasifica como recordatorio válido |
| Oportunidad descartada, realizada o cerrada | No genera avisos de tareas |

No se supone que una llamada se hizo por cambiar el estado comercial. Hay que registrar su resultado. Tampoco una gestión nueva cualquiera resuelve automáticamente las antiguas: se elige cuál se está completando.

Cerrar una oportunidad no marca sus tareas como realizadas; solo retira sus avisos. El historial conserva lo que realmente se registró.

## Cambio de base versión 3 a 4

Se añade resueltaPorId a SeguimientoEntity. Es una clave foránea opcional a otra fila de seguimientos.

```text
Seguimiento 10
  Acción: llamada inicial
  Resultado: no respondió
  Próxima acción: volver a llamar
  Fecha próxima: ayer
  resueltaPorId: 11
            ↓
Seguimiento 11
  Acción: volver a llamar
  Resultado: contestó y pidió propuesta
  Autor: usuario que completó la acción
  Fecha/hora: momento de registro
  Próxima acción: enviar propuesta (si se programa)
```

Así el resultado, autor y fecha de resolución se guardan una sola vez, en la gestión que los produjo. La tarea original conserva su fecha y contenido. Un índice único impide reutilizar una resolución para completar dos tareas distintas.

MigracionRecordatorios ejecuta ALTER TABLE y crea el índice sin reconstruir ni borrar los datos. AppDatabase registra los caminos 1 → 2 → 3 → 4, 2 → 3 → 4 y 3 → 4.

Los registros antiguos con próxima acción quedan abiertos porque no se puede inferir si ya se realizaron. Puede ser necesario completar manualmente tareas históricas que nunca tuvieron resultado registrado.

## Qué hace cada archivo

| Archivo | Cómo participa |
| --- | --- |
| SeguimientoEntity.kt | Guarda el vínculo resueltaPorId; la proyección de historial lee sus datos de resolución |
| MigracionRecordatorios.kt | Añade columna y restricción en la base instalada |
| CatalogoDao.kt | Consulta avisos y actualiza una tarea solo si sigue sin resolver |
| OportunidadRepository.kt | Comprueba permisos, registra resultado y resuelve en una transacción |
| RecordatorioSeguimiento.kt | Resultado de consulta para Inicio; no es una tabla duplicada |
| utils/Recordatorios.kt | Clasifica fechas válidas en atrasado, hoy o pendiente |
| utils/ValidarSeguimiento.kt | Reglas compartidas para evitar diferencias entre UI y Repository |
| InicioUiState.kt | Contiene las tareas visibles junto a las oportunidades |
| InicioViewModel.kt | Combina consultas y publica un resumen actualizado |
| InicioScreen.kt | Muestra tarjetas, contadores y accesos directos al registro de resultado |
| DetalleUiState.kt | Identifica la tarea seleccionada para resolución |
| DetalleViewModel.kt | Precarga acción, valida resultado y coordina la resolución |
| SeguimientoScreen.kt | Formulario e historial con resolución visible |
| Navegacion.kt | Acepta pendienteId opcional para abrir una tarea desde Inicio |

## Por qué se usa una transacción

Completar una tarea requiere insertar el resultado y enlazarlo con la tarea original. Si una parte falla, se revierten ambas. La consulta UPDATE solo modifica una fila si resueltaPorId sigue siendo null; si otra operación la completó, no se guarda un segundo resultado por accidente.

Repository verifica que la tarea sea de la oportunidad abierta y que el usuario tenga acceso. No basta cambiar el ID de la ruta para resolver acciones de otra oportunidad. Las tareas siguen al responsable actual de la oportunidad, no al autor histórico de quien las programó.

## Avisos comerciales adicionales

- Sin contacto: oportunidad activa sin contacto principal vinculado. Un nombre suelto en observaciones no cuenta como contacto asociado.
- Sin respuesta: oportunidad en Propuesta enviada o En espera. Se basa en el estado registrado, no comprueba correo externo ni presupone que se envió un mensaje real.
- Próximos eventos: tres fechas futuras más cercanas de oportunidades activas.

La fecha de clasificación se actualiza al entrar o regresar a Inicio. No se añadió un servicio de fondo ni un temporizador de medianoche.

## Verificación realizada

- APK de depuración generado con la configuración habitual: BUILD SUCCESSFUL.
- 19 pruebas unitarias aprobadas, cero fallos.
- Pruebas instrumentales de Room compiladas. No ejecutadas: no había emulador ni dispositivo conectado.
- SQL de migración 3 → 4 probado con una tarea anterior: conserva datos y queda abierta por defecto.
- Columnas y claves de seguimiento migrado contrastadas con el esquema generado por Room.
- SQL de resolución comprobado: la tarea desaparece de avisos y otro intento no cambia la fila.

RecordatoriosRoomTest prepara bases aisladas en memoria y prueba resolución, historial, doble resolución, permisos, reasignación y rechazo de tarea de otra oportunidad. NormalizacionRoomTest también recorre el nuevo camino hasta versión 4 y conserva una tarea antigua.

La verificación SQL y las pruebas unitarias no sustituyen el recorrido manual ni la ejecución de las pruebas instrumentales en Android.
