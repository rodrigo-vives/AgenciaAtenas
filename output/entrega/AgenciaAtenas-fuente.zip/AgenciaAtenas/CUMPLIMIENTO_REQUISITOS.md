# Matriz de cumplimiento - base 5

Actualizada el 18/10/2026 para Omar Martínez y Rodrigo Vivez. Se contrastó el caso PDF con la checklist proporcionada. **Implementado no significa que cada recorrido de UI se haya probado manualmente.** Las herramientas verifican reglas, base y archivos; se indican las comprobaciones que requieren al equipo o una aplicación externa.

## Cambio elegido por el equipo

Sin migraciones. La base 5 requiere una instalación limpia. Usar otro emulador preserva la base 4 del anterior. No hay borrado automático. Se conservó output/entrega/AgenciaAtenas-fuente-base4.zip como referencia anterior; la entrega vigente es AgenciaAtenas-fuente.zip.

## Checklist, criterio por criterio

| Criterio | Estado | Evidencia o condición |
| --- | --- | --- |
| Implementar 2 roles: Ejecutivo Comercial y Supervisor Comercial. | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Disponer de al menos 4 cuentas ficticias de prueba (3 ejecutivos y 1 supervisor). | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Implementar inicio y cierre de sesión mediante cuentas locales ficticias. | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Mostrar pantallas, opciones y funcionalidades diferentes según el rol. | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Restringir el acceso a oportunidades y acciones no autorizadas. | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Permitir al supervisor asignar y reasignar oportunidades a ejecutivos. | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Impedir que el ejecutivo confirme o descarte definitivamente oportunidades. | Implementado | UsuarioRepository, SesionActual y OportunidadRepository; pruebas de autenticación, rol, asignación y alcance en Room. |
| Implementar al menos 8 pantallas funcionales y conectadas mediante navegación. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Implementar inicio de sesión y Dashboard con información según el rol. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Mostrar listado de oportunidades con búsqueda y filtros por estado o prioridad. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Implementar pantalla de detalle de oportunidad con información completa. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Implementar formulario para crear y editar oportunidades comerciales. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Implementar registro y consulta de organizaciones y contactos corporativos ficticios. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Implementar pantalla de seguimiento con historial y registro de nuevas gestiones. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Implementar panel de supervisor con consulta global y asignación de responsables. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Permitir actualizar los estados de las oportunidades respetando los permisos y transiciones. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Registrar fecha, ubicación, tipo de evento, público esperado y prioridad de cada oportunidad. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Mostrar oportunidades próximas, seguimientos pendientes y gestiones atrasadas. | Implementado | Navegacion y Screen conectadas; reglas y consultas comprobadas. El recorrido de todos los formularios en UI debe repetirse por ambos integrantes. |
| Utilizar Room/SQLite para persistencia local. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Presentar modelo de datos relacional normalizado (referencia: tercera forma normal, 3FN). | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Implementar como mínimo las entidades Usuario, Organización, Contacto, Oportunidad y Seguimiento. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Implementar claves primarias, claves foráneas y relaciones entre entidades. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Realizar operaciones de creación, consulta y actualización sobre datos reales. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Conservar oportunidades, contactos y seguimientos después de cerrar la aplicación. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Aplicar arquitectura MVVM: UI, ViewModel, Repository y fuente de datos. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Gestionar el estado de las pantallas utilizando ViewModel y StateFlow. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Evitar duplicación innecesaria de datos y conservar el historial de gestiones. | Implementado | AppDatabase versión 5, siete entidades, PK/FK, JOIN y transacciones; pruebas instrumentales ejecutadas. |
| Validar todos los campos obligatorios de los formularios. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Validar formatos de correo, teléfono, fechas, longitudes y valores numéricos. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Comprobar reglas de negocio, como fechas coherentes y costos no negativos. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Mostrar mensajes específicos debajo de los campos incorrectos. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Utilizar indicadores visuales de error, supportingText e íconos apropiados. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Mostrar confirmaciones de éxito y mensajes claros ante errores de operación. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Impedir guardar oportunidades, contactos o seguimientos con información inválida. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Mantener los valores ingresados cuando falle una validación. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Mantener la lógica de validación separada de los Composables. | Implementado | ValidarOportunidad, ValidarCatalogo, ValidarSeguimiento, ValidarResultado y Campo; pruebas unitarias de reglas y persistencia en Room. |
| Implementar la cámara del dispositivo para capturar fotografías de eventos u oportunidades. | Implementado | TakePicture/FileProvider y ACTION_INSERT; archivos probados. Guardado real de Calendar pendiente en dispositivo con calendario/cuenta configurado. |
| Implementar integración con el calendario del dispositivo para programar eventos o seguimientos. | Implementado; verificación externa pendiente | Exporta fechas y horas al editor nativo. Falta guardar y localizar un evento con Calendar configurado. |
| Mostrar una vista previa de las fotografías capturadas. | Implementado | TakePicture/FileProvider y ACTION_INSERT; archivos probados. Guardado real de Calendar pendiente en dispositivo con calendario/cuenta configurado. |
| Asociar y conservar las evidencias fotográficas con su oportunidad correspondiente. | Implementado | TakePicture/FileProvider y ACTION_INSERT; archivos probados. Guardado real de Calendar pendiente en dispositivo con calendario/cuenta configurado. |
| Utilizar correctamente los datos de fecha y hora al crear eventos de calendario. | Implementado; verificación externa pendiente | Exporta fechas y horas al editor nativo. Falta guardar y localizar un evento con Calendar configurado. |
| Gestionar correctamente archivos, URIs, permisos y cancelaciones cuando corresponda. | Implementado | TakePicture/FileProvider y ACTION_INSERT; archivos probados. Guardado real de Calendar pendiente en dispositivo con calendario/cuenta configurado. |
| Utilizar Jetpack Compose y Material Design 3. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Centralizar colores y tipografías en ui/theme. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Evitar colores hexadecimales repetidos directamente en las pantallas. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Definir colores semánticos para estados de oportunidades, éxito, advertencia y error. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Definir una jerarquía tipográfica consistente utilizando MaterialTheme.typography. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Mantener consistencia visual en botones, tarjetas, formularios, íconos y espaciados. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Implementar al menos 3 interacciones animadas funcionales mediante 2 mecanismos de animación. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Utilizar animaciones que aporten retroalimentación y no dificulten la navegación. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Presentar una interfaz intuitiva, legible, profesional y sin saturación visual. | Implementado; revisión visual parcial | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Adaptar el contenido a diferentes tamaños de pantalla y permitir desplazamiento cuando sea necesario. | Implementado; revisión visual parcial | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Mostrar estados vacíos, indicadores de carga y confirmaciones cuando corresponda. | Implementado | MaterialTheme, colores semánticos, MensajeOperacion y tres animaciones; perfil revisado en claro/oscuro con letra ampliada. Resto de pantallas requiere repaso visual del equipo. |
| Entregar un proyecto Android Studio funcional y ejecutable. | Implementado | README, fuentes y guías preparados; colaboración y envío son acciones externas. |
| Utilizar GitHub con commits técnicos y participación demostrable de ambos integrantes. | Pendiente externo | Falta enlace del repositorio y commits reales de ambos. No se fabricó historial. |
| Incluir README con descripción, integrantes, funcionalidades, arquitectura e instrucciones de ejecución. | Implementado | README, fuentes y guías preparados; colaboración y envío son acciones externas. |
| Utilizar información ficticia para organizaciones, contactos, usuarios y eventos de prueba. | Implementado | README, fuentes y guías preparados; colaboración y envío son acciones externas. |
| Entregar el código fuente mediante AVA según las instrucciones oficiales. | Pendiente externo | El equipo debe realizar el envío según instrucciones oficiales. |
| Prepararse individualmente para ejecutar, explicar, justificar y modificar el código durante la defensa. | Pendiente del equipo | Practicar ejecución, explicación y modificación usando las guías; no se puede certificar con una prueba automática. |

Bonus: ícono propio de maletín/gestión, adaptativo y con alternativa para API 24/25.

## Cobertura adicional del PDF

- Oportunidad/evento: nombre, tipo, descripción, fuente, detección, responsable, prioridad, potencial, estado, fechas/horario, comuna/región/ubicación, públicos, asistentes, condiciones, requisitos, costos, espacios y observaciones. Cada oportunidad incorpora un evento; no se duplica una tabla Evento para la misma relación uno a uno del MVP.
- Organización: los campos complementarios de p. 8 se registran; eventos e historial se consultan por relación, sin duplicar listas en una celda.
- Contacto: organización, cargo, área, correo/teléfono ficticios y medio. Los campos de estado/fecha de último contacto que p. 9 propone opcionalmente no se agregaron como requisitos nuevos.
- Historial por contacto: vínculo contactoId en cada gestión. Cambiar el contacto principal no cambia el pasado; el usuario solo consulta oportunidades a las que tiene acceso actual.
- Resultado: formulario propio con fecha, evaluación, observaciones, aprendizajes e indicadores opcionales. Datos desconocidos siguen null. Relación normalizada Resultado -> Seguimiento -> Oportunidad/Usuario.
- Perfil: consulta de cuenta, nombre ficticio, rol, estado y cantidad visible; sin mostrar credenciales. Los datos opcionales de área/sucursal no son necesarios para los dos roles de la checklist.
- Alertas: eventos próximos, pendientes, atrasados, propuestas sin respuesta, sin contacto y sin gestión comercial. Las notificaciones se mantienen internas como permite el caso.
- Filtros: todos los criterios indicados en p. 14 y 18, combinables y sin ampliar permisos.
- Android es el alcance de la asignatura. APIs productivas, iOS, mapas, correo real, Spring/Retrofit y publicación no se impusieron como requisitos de Evaluación 2 cuando el caso los menciona como contexto o futuras tecnologías.

## Evidencia de ejecución

- APK de depuración: compilación correcta.
- Pruebas unitarias: 41 aprobadas, cero fallos/errores.
- Pruebas instrumentales en Android API 37: 11 aprobadas, cero fallos/errores. Se usó emulator-5580 en copia temporal solo lectura.
- Lint: ejecución correcta, cero errores y 14 advertencias de mantenimiento.
- Arranque e ingreso con admin/1234 en base limpia: comprobados mediante la interfaz.
- Perfil del supervisor: consultado en pantalla, también en modo oscuro y letra ampliada.
- Cámara: la captura fue confirmada previamente por el usuario; las pruebas nuevas comprueban archivos persistentes, cancelación y denegación a otro ejecutivo. Falta repasar el flujo completo de cámara en la versión final.
- Calendar: editor integrado y conversión de fechas probada; guardado final en Calendar pendiente de cuenta/calendario configurado.
- No se afirmó haber realizado cada recorrido manual del equipo ni el envío a AVA.


## Para entregar

1. Completar sección y repositorio. README ya incluye los nombres facilitados por el usuario.
2. Realizar commits técnicos auténticos de Omar y Rodrigo; no atribuir al otro cambios que no hizo.
3. Probar Camera/Calendar en un dispositivo configurado y repetir el recorrido de GUIA_COMPLEMENTOS_CASO.md.
4. Entregar el ZIP fuente vigente y el APK de depuración si se solicita, según formato del AVA.
5. Practicar individualmente el recorrido de un dato y una modificación sencilla. El código está comentado para apoyar ese estudio.

Última pasada de legibilidad: estados separados y lecturas del perfil/historial mediante Repository. Compilación, 41 pruebas unitarias y Lint correctos; pruebas instrumentales compiladas. Las 11 pruebas Android corresponden a la ejecución funcional anterior de base 5.
