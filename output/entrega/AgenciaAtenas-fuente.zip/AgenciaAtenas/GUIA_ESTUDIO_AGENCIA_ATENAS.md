> Revisión de lectura del 18/10/2026: consultar REVISION_GENERAL_EQUIPO.md para el mapa actual y las adaptaciones respecto a los PPT. Las secciones históricas de migraciones se conservan solo como contexto.

> Actualización: se retiraron las migraciones históricas para simplificar la entrega. Room crea directamente las tablas actuales. Se mantiene la versión 4 para conservar las instalaciones que ya usan esa estructura. Solo las bases anteriores necesitan borrar datos o reinstalar la aplicación. Las explicaciones de migraciones que aparecen más abajo son históricas y ya no describen código vigente.

# Guía de estudio de Agencia Atenas

Esta guía explica el proyecto que tienen ahora: cómo leerlo, seguir una operación, probarla y mejorarla. Está pensada para estudiar con Android Studio abierto. El objetivo es que ambos puedan explicar y modificar el código, no memorizar nombres.

La aplicación organiza oportunidades comerciales para participar en eventos: identificar una actividad, investigar a su organización, establecer contacto, registrar gestiones y resolver si se participa. Una oportunidad es la posibilidad comercial; un evento es la actividad; un seguimiento es una acción realizada durante esa gestión.

**Actualización de base v3:** leer [NORMALIZACION_BASE_DATOS.md](NORMALIZACION_BASE_DATOS.md) para el cambio de usuarios y relaciones. La verificación de migración en dispositivo sigue pendiente.

**Alcance:** hay un avance funcional del reparto inicial y partes del checklist. Todavía faltan requisitos. Un comentario o una pantalla existente no demuestran por sí solos que un requisito esté probado.

## Índice

1. Cómo estudiar en pareja
2. Recorrido y archivos
3. Kotlin que necesitan
4. Estado y Compose
5. Seguir un campo
6. Validaciones y mensajes rojos
7. Guardar y editar
8. Room y relaciones
9. Navegación y ciclo de vida
10. Roles y estados
11. Seguimiento e historial
12. Fechas y alertas
13. Prueba manual
14. Encontrar errores
15. Mejorar el código
16. Ejercicios
17. Preguntas de defensa
18. Plan de estudio

## 1. Cómo estudiar en pareja

Una persona maneja Android Studio y la otra explica qué debería ocurrir antes de ejecutar. Después intercambien los papeles. Si no pueden señalar el archivo y la función responsables, sigan el recorrido del dato antes de modificarlo.

Para cada función importante respondan:

- ¿Quién la llama y qué recibe?
- ¿Qué lee, devuelve y modifica?
- ¿Qué pasa si falla o si el dato está vacío?
- ¿Su efecto queda en memoria o en Room?
- ¿Por qué está en esa capa?

Usen un registro ficticio reconocible. Primero completen un recorrido correcto; después provoquen errores. Cambien una cosa por vez para poder atribuir el resultado a ese cambio.

## 2. Recorrido y archivos

```mermaid
flowchart TD
    L[Login] --> I[Inicio según rol]
    I --> O[Listado]
    I --> G[Organizaciones]
    I --> C[Contactos]
    I --> P[Panel de supervisor]
    O --> N[Crear]
    O --> D[Detalle]
    N --> D
    D --> E[Editar con el mismo formulario]
    E --> D
    D --> S[Seguimiento e historial]
    P --> D
```

Crear y Editar reutilizan un formulario. Organizaciones y Contactos comparten `CatalogoScreen`, configurada con `esContacto`, pero tienen rutas y tareas diferentes. Confirmen con el profesor su criterio para contar pantallas; no cuenten Crear/Editar dos veces.

| Cuenta | Rol | Contraseña de prueba |
| --- | --- | --- |
| `admin` | Supervisor | `1234` |
| `ejecutivo1` | Ejecutivo | `1234` |
| `ejecutivo2` | Ejecutivo | `1234` |
| `ejecutivo3` | Ejecutivo | `1234` |

Son cuentas iniciales ficticias guardadas en UsuarioEntity. El login consulta Room; el rol proviene de la fila. La sesión queda en memoria; los usuarios y demás registros permanecen en Room.

El código principal está dentro de `app/src/main/java/com/agencia/atenas/`. Las rutas de la tabla parten de ahí.

| Archivo o grupo | Responsabilidad | Qué localizar |
| --- | --- | --- |
| `MainActivity.kt` | Arrancar interfaz y tema | `Navegacion()` |
| `ui/Navegacion.kt` | Rutas y regreso | NavHost, callbacks, id |
| `ui/CrearUiState.kt` | Borrador del formulario | Valores, errores, guardando |
| `ui/CrearScreen.kt` | Mostrar y conectar campos | Campo, Selector, efectos |
| `ui/CrearViewModel.kt` | Cargar, modificar, validar, guardar | cargar, cambiar, guardar |
| `ui/CamposFormulario.kt` | Claves, etiquetas y lectura de valores | camposFormulario, valor |
| `ui/ComponentesFormulario.kt` | Elementos visuales compartidos | Pagina, Campo, Selector |
| `ui/ListaScreen.kt` y `ListaViewModel.kt` | Consultar y filtrar | TarjetaGestion, ListaUiState.gestionesFiltradas |
| `ui/DetalleScreen.kt` | Consultar y abrir acciones | Edición y estado |
| `ui/DetalleUiState.kt` y `DetalleViewModel.kt` | Estado y lógica de detalle/seguimiento | cargar, registrar, cambiarEstado |
| `ui/SeguimientoScreen.kt` | Nueva gestión e historial | Acción, resultado y próxima acción |
| `ui/CatalogoScreen.kt`, `CatalogoUiState.kt`, `CatalogoViewModel.kt` | Organizaciones y contactos | esContacto, organizacionId |
| `ui/InicioScreen.kt`, `InicioUiState.kt`, `InicioViewModel.kt` | Resumen y lógica compartida con panel | Consulta y asignación |
| `ui/SupervisorScreen.kt` | Asignar ejecutivo | Selector y permiso |
| `data/OportunidadRepository.kt` | Operaciones y autorización | obtener, guardar, transacciones |
| `data/CatalogoRepository.kt` | Guardado de catálogos | Comprobaciones e inserciones |
| `data/OportunidadDao.kt`, `CatalogoDao.kt` | Operaciones Room | @Query, @Insert, @Update |
| `data/*Entity.kt` | Tablas y relaciones | id y claves foráneas |
| `data/AppDatabase.kt` | Base y migración | versión 2, MIGRACION_1_2 |
| `data/ReglasEstadoOportunidad.kt` | Transiciones por estado/rol | estadosPermitidos |
| `utils/Validaciones.kt` | Correo, teléfono y objeto Fechas | Reglas reutilizables |
| `utils/ValidarOportunidad.kt` | Validación del formulario completo | Mapa de errores |
| `utils/AlertasEvento.kt` | Proximidad por fecha | diasDeAlertaEvento |
| `utils/SesionActual.kt` | Usuario y cuentas de prueba | esSupervisor, cerrar |
| `ui/theme/Color.kt` | Colores de tarjetas | Colores semánticos |

## 3. Kotlin que necesitan

### val, data class y copy

`val` impide reasignar la propiedad. No hace automáticamente inmutable cualquier objeto referenciado. Aquí se usan propiedades val y nuevas instancias para cambiar el estado explícitamente.

```kotlin
val anterior = CrearUiState(nombreOportunidad = "Feria A")
val nuevo = anterior.copy(nombreOportunidad = "Feria B")
```

El objeto anterior sigue con Feria A; el nuevo tiene Feria B y conserva las otras propiedades. `copy` no guarda en Room ni realiza una copia profunda de todos los objetos anidados.

### Lambdas, it y callbacks

Una lambda es una función pasada como valor:

```kotlin
onValueChange = { textoNuevo ->
    viewModel.cambiar("nombreOportunidad", textoNuevo)
}
```

Con un único parámetro se puede usar `it`. En bloques anidados conviene usar nombres explícitos para saber a qué valor se refiere cada uno.

`onVolver: () -> Unit` no recibe argumentos ni devuelve resultado útil. `onGuardado: (Int) -> Unit` recibe el identificador guardado. La pantalla llama estas funciones y quien la creó decide qué hacer, por ejemplo navegar.

### Null y conversiones

| Código | Significado |
| --- | --- |
| `Int?` | Entero o ausencia de valor |
| `item?.estado` | Accede solo si item no es null |
| `valor ?: alternativa` | Usa alternativa si valor es null |
| `item ?: return` | Sale si no existe item |
| `toIntOrNull()` | Devuelve entero o null |
| `!!` | Afirma que no es null; falla si lo es |

El guardado usa `!!` en fechas después de validar. Su seguridad depende de no saltarse esa validación. Una mejora es convertir una sola vez y comprobar el resultado antes de construir la entidad.

`filter` conserva elementos, `map` los transforma, `forEach` ejecuta una acción por elemento y `firstOrNull` encuentra el primero o devuelve null.

`isBlank` detecta vacío o espacios. `trim` elimina espacios de los extremos. `check` y `require` lanzan excepciones si una condición falla; normalmente require revisa argumentos y check el estado necesario para operar.

## 4. Estado y Compose

```text
Usuario escribe → ViewModel cambia estado → StateFlow emite
→ Compose actualiza las partes que dependen de ese estado
```

UiState describe **qué información tiene la pantalla**. StateFlow permite **observar sus cambios**.

```kotlin
private val _uiState = MutableStateFlow(CrearUiState())
val uiState = _uiState.asStateFlow()
```

MutableStateFlow permite actualizar el estado. asStateFlow expone una vista de lectura. El guion bajo es convención; private limita el acceso.

La pantalla observa con `collectAsStateWithLifecycle()`. La colección respeta su ciclo de vida. Una actualización puede recomponer los componentes necesarios; no reinicia la aplicación ni implica consultar Room por cada tecla.

`remember` conserva valores entre recomposiciones mientras ese punto sigue en la composición. Sirve para abierto/cerrado del menú. No guarda un borrador después de terminar el proceso.

El ViewModel suele sobrevivir a una recreación por giro si se mantiene su propietario, pero no garantiza recuperar datos tras la muerte del proceso. Room, SavedStateHandle o un borrador persistido resuelven problemas distintos; no son intercambiables sin diseñarlos.

## 5. Seguir un campo

Usen `nombreOportunidad` como hilo conductor:

1. CrearUiState declara su valor inicial vacío.
2. CamposFormulario relaciona su clave con la etiqueta.
3. `CrearUiState.valor(clave)` lee la propiedad mediante when.
4. CrearScreen entrega valor y error a Campo.
5. Campo dibuja OutlinedTextField y comunica cambios.
6. La pantalla llama `CrearViewModel.cambiar(clave, texto)`.
7. El when genera una copia con el nombre nuevo.
8. El flujo publica la copia y el campo muestra el texto.

Esta metadata evita repetir muchos bloques visuales, pero tiene un costo: las claves son texto. Un error tipográfico puede desconectar el campo sin que el compilador lo detecte.

Agregar un campo requiere revisar estado, metadata, lectura valor, actualización cambiar, validación, conversión de guardado y detalle. Si se persiste también requiere entidad y, para una base instalada, migración.

Organización y contacto se eligen por identificadores. Sus nombres se presentan en el borrador, pero no se copian a la entidad guardada. OportunidadDetalle obtiene las etiquetas actuales mediante JOIN.

## 6. Validaciones y mensajes rojos

| Etapa | Responsable | Salida |
| --- | --- | --- |
| Comprobar reglas | ValidarOportunidad | Mapa clave → mensaje |
| Publicar errores | CrearViewModel | UiState.errores actualizado |
| Mostrar error | Campo en ComponentesFormulario | isError y supportingText |

```kotlin
mapOf(
    "nombreOportunidad" to "Este campo es obligatorio",
    "fechaTermino" to "No puede ser anterior al inicio"
)
```

Cada campo consulta su clave. Si no hay entrada obtiene null. `isError = error != null` activa el rojo; supportingText muestra el mensaje. Al editar se limpia ese error, pero eso no demuestra que el texto nuevo sea válido: se valida de nuevo al guardar.

Reglas actuales de oportunidad:

- Obligatorios: nombre, tipo, detección, inicio, comuna, región y público esperado. Prioridad solo Alta/Media/Baja; empieza en Media.
- Nombre: máximo 120; límite general de campos descritos en metadata: 2000.
- Fechas informadas reales en DD/MM/AAAA. Término no anterior al inicio.
- Asistentes: opcional; entero no negativo y representable como Int.
- Costo: opcional; número finito no negativo, punto o coma decimal.
- Correo y teléfono: opcionales; si se informan, formato válido.
- Horario informado: HH:mm a HH:mm; con fechas iguales, término posterior al inicio.

El correo se comprueba con regex básica, no se verifica que exista. El teléfono admite caracteres controlados y entre 8/15 dígitos; no comprueba que el número esté activo.

Catálogos y seguimiento todavía tienen parte de sus validaciones en sus ViewModels/Repository. Pueden reunir funciones auxiliares en Validaciones.kt, pero no deben incluir allí componentes visuales, navegación ni consultas SQL.

Usar datos ficticios en las pruebas es obligatorio. Eso no significa completar con información inventada campos desconocidos que pueden quedar opcionales.

## 7. Guardar y editar

1. guardar evita iniciar mientras carga/guarda.
2. validarFormulario publica errores y decide continuar.
3. Se captura el estado actual y activa guardando.
4. Una corrutina construye GestionOportunidadEntity, limpia espacios y convierte fechas/números.
5. Repository verifica sesión y decide Insert o Update.
6. El DAO escribe en Room; Insert devuelve id generado.
7. El ViewModel publica guardadoId después del éxito.
8. CrearScreen observa ese id con LaunchedEffect y llama onGuardado.
9. Navegacion abre Detalle. Si falla, se muestra error y conserva el borrador.

`viewModelScope.launch` inicia una corrutina ligada al ViewModel. Permite llamar funciones suspend sin bloquear la interfaz esperando. No crea necesariamente un hilo nuevo. Room administra la ejecución de sus consultas suspendidas.

`suspend` permite suspender/reanudar; no significa automáticamente segundo plano. Trabajo pesado de CPU requiere decidir el contexto apropiado.

CancellationException se relanza para respetar la cancelación. Mostrarla como fallo normal podría avisar de un error al usuario simplemente por abandonar una pantalla.

### Edición

Id cero indica creación; un id existente permite cargar datos. inicializado evita recargar por recomposición y sobrescribir lo escrito. El estado comercial y el historial anterior se conservan. Responsable/estado no se cambian por este guardado: tienen operaciones propias con permisos.

### Actualización del listado

Room emite la consulta observada con Flow cuando cambian sus tablas. Repository filtra el alcance del usuario; ListaViewModel publica la lista; ListaScreen la observa. CrearViewModel no llama a ListaViewModel: se conectan mediante la persistencia compartida.

## 8. Room y relaciones

```mermaid
flowchart LR
    S[Screen] --> V[ViewModel]
    V --> R[Repository]
    R --> D[DAO]
    D --> B[(SQLite mediante Room)]
```

| Concepto | Significado |
| --- | --- |
| Entity | Clase que representa tabla y columnas |
| PrimaryKey | Identificador único de una fila |
| autoGenerate | La base genera el identificador al insertar |
| DAO | Lecturas/escrituras concretas, con SQL y anotaciones |
| Repository | Coordina operaciones y autorización |
| AppDatabase | Declara tablas y proporciona DAO |
| Converter | Traduce enum a texto guardable y viceversa |

No editen AppDatabase_Impl ni los DAO_Impl: Room genera esas implementaciones al compilar.

Relaciones actuales:

```text
Organización 1 ─── N Contactos
Oportunidad  1 ─── N Seguimientos
```

La clave foránea organizacionId impide contactos sin organización existente. oportunidadId relaciona gestiones con oportunidades. Un índice facilita búsquedas por clave; no convierte el nombre de organización en único.

### Normalización en versión 3

UsuarioEntity persiste usuarios y roles. Oportunidad referencia responsableId y organizacionId; el contacto principal se vincula en oportunidad_contacto. Seguimiento referencia su autor por responsableId. Las etiquetas se reconstruyen con JOIN en OportunidadDetalle y SeguimientoDetalle, que no son tablas.

Las copias de organización/contacto se retiraron de la oportunidad. Ya no se filtra por nombre: se usa organizacionId. El diseño supone un evento por oportunidad y un contacto principal opcional. Consulten NORMALIZACION_BASE_DATOS.md para las dependencias y ejemplos.

### Migraciones 1 a 2 y 2 a 3

AppDatabase registra ambos caminos. La versión 3 conserva IDs de oportunidades y gestiones, reutiliza catálogos con información coincidente y conserva autores antiguos desconocidos como cuentas inactivas. Los datos no se borran para actualizar.

Null en asistentes significa desconocido; cero significa cero informado.

### Transacciones

Cambiar estado y asignar escriben oportunidad más historial con withTransaction. Ambas escrituras se confirman o revierten juntas si falla la operación. Sin eso podría quedar un estado nuevo sin historial o un historial que describe un cambio que no se guardó.

## 9. Navegación y ciclo de vida

NavController controla la pila de destinos; NavHost declara el contenido de cada ruta.

- navigate abre un destino.
- popBackStack retira el actual y vuelve al anterior.
- popUpTo retira parte de la pila, por ejemplo al cerrar sesión.

Navegar reiteradamente a Inicio puede acumular copias; volver no es necesariamente navegar a otra copia del mismo destino.

`detalle/{id}` recibe un argumento de texto. Se convierte con toIntOrNull antes de consultar. Se pasa id para leer los datos vigentes, no una copia grande del registro en la ruta.

LaunchedEffect(id) se inicia al entrar en la composición y cuando cambia la clave. No se vuelve a ejecutar por cada tecla. LifecycleEventEffect(ON_RESUME) refresca Detalle cuando vuelve al primer plano, por ejemplo al regresar de Editar.

Volver atrás abandona el formulario sin guardar. No existe aviso de cambios sin guardar ni borrador persistente. La permanencia temporal del ViewModel no debe presentarse como garantía de recuperación tras terminar el proceso.

## 10. Roles y estados

SesionActual.esSupervisor usa el rol de la fila autenticada. Repository vuelve a leer el usuario en Room para autorizar operaciones. El Repository filtra:

```text
Supervisor → todas las oportunidades
Ejecutivo  → solo aquellas cuyo responsable coincide con su usuario
```

obtener(id) también verifica acceso. Esconder un botón solo afecta presentación: la operación de datos también debe autorizarse. asignar exige supervisor y un destinatario de la lista de ejecutivos.

Una oportunidad nueva queda a cargo de quien la crea. Admin puede crear y luego asignar. Después ejecutivo1 debe ver la asignada a él, pero ejecutivo2 no.

La función estadosPermitidos permite elegir directamente entre estados de gestión:
Identificado, Contacto pendiente, Contacto realizado, Propuesta enviada, En espera y Requiere seguimiento.
No es obligatorio pasar por cada uno: pueden registrar la situación real en una sola selección.

Solo el supervisor puede confirmar o descartar. Activación realizada requiere partir de Confirmado.
Descartado y Activación realizada solo permiten pasar a Cerrado. Cerrado no se reabre.
El estado actual no se ofrece como destino porque no produciría un cambio real.
La política sigue siendo una decisión del proyecto: el checklist fija permisos, no esta matriz completa.

La pantalla usa la función para sus opciones y Repository la utiliza para autorizar. Mantener una sola regla evita que selector y guardado diverjan.

Las cuentas iniciales ahora están persistidas. La contraseña se compara por un hash sencillo de demostración local; no se presenta como autenticación productiva.

## 11. Seguimiento e historial

**Actualización versión 4:** Inicio ya muestra pendientes, atrasados y recordatorios. La resolución se vincula mediante resueltaPorId y conserva el historial; leer [PENDIENTES_Y_RECORDATORIOS.md](PENDIENTES_Y_RECORDATORIOS.md).

Una gestión guarda acción, resultado, usuario, fecha/hora, observaciones y opcionalmente próxima acción/fecha. Acción y resultado son obligatorios. Próxima acción y fecha se completan juntas o quedan ambas vacías.

DetalleViewModel.registrar valida el borrador y construye SeguimientoEntity. Repository comprueba acceso mediante obtener antes de insertar. Cada gestión es una fila nueva; no se reemplaza el texto anterior.

La consulta usa Flow y ordena id descendente: muestra primero lo insertado más recientemente. No equivale a ordenar por una fecha de acción editable; hoy fecha/hora se asigna al registrar.

También se registran cambios de estado y asignaciones. historialObservaciones de la tabla antigua se conserva y se muestra en Detalle por compatibilidad.

La autoría ya usa una relación con UsuarioEntity. resueltaPorId indica qué gestión completó la próxima acción. Las consultas retiran tareas resueltas y separan pendientes/atrasados en Inicio.

## 12. Fechas y alertas

| Lugar | Formato | Razón |
| --- | --- | --- |
| Pantalla | 17/10/2026 | Preferencia de los usuarios |
| Room | 2026-10-17 | Orden cronológico por texto ISO |

Fechas.aIso exige DD/MM/AAAA y fecha real. isLenient = false evita ajustar 31 de febrero a otro día. visible convierte para mostrar y, si falla, conserva el texto anterior para no ocultar valores que necesitan corrección.

diasDeAlertaEvento devuelve 0 para hoy, 1 para mañana, 2 a 7 para próximos días y null para ausencia de aviso. Excluye fechas inválidas, pasadas, descartados, realizados y cerrados.

Siete días es una decisión del proyecto: el Word no fija el plazo. La diferencia se calcula en UTC para que una fecha sin hora no se distorsione por días de 23/25 horas. La fecha de hoy se obtiene antes en la zona del dispositivo.

El color de proximidad tiene prioridad sobre el color de estado. El estado sigue escrito en la tarjeta y un mensaje explica la proximidad. Los colores están en ui/theme/Color.kt.

Es un aviso interno, no una notificación del sistema. El día se actualiza al volver al primer plano; no existe temporizador de medianoche si se deja la pantalla abierta durante toda la noche.

## 13. Prueba manual

Usen datos ficticios y fechas relativas al día de prueba para las alertas. Una persona ejecuta y la otra registra resultado y archivo responsable.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Login vacío o incorrecto | Errores sin entrar |
| 2 | Entrar como admin | Inicio con panel |
| 3 | Registrar organización ficticia | Aparece en catálogo |
| 4 | Guardar contacto sin organización | Error específico |
| 5 | Elegir organización y guardar contacto válido | Contacto visible y asociado |
| 6 | Guardar oportunidad vacía | Errores por campo; no guarda |
| 7 | Fecha 31/02/2026, costo -1, asistentes abc | Rechazo específico |
| 8 | Completar mínimos y guardar | Abre Detalle con datos correctos |
| 9 | Editar descripción y guardar | Detalle actualizado |
| 10 | Registrar acción sin resultado | Conserva borrador y muestra error |
| 11 | Completar resultado | Aparece una fila de historial |
| 12 | Cambiar estado permitido | Nuevo estado y fila de historial |
| 13 | Reasignar a ejecutivo1 | Responsable nuevo e historial |
| 14 | Entrar como ejecutivo2 | No ve la oportunidad de ejecutivo1 |
| 15 | Entrar como ejecutivo1 | La ve; no puede confirmar/descartar |
| 16 | Evento mañana | Aviso Evento mañana |
| 17 | Evento hoy, siete y ocho días | Solo alerta dentro de ventana |
| 18 | Terminar proceso, volver e ingresar | Persisten registros; requiere login |

Rotar, volver atrás y terminar el proceso son pruebas diferentes. Anoten cuál hicieron. No desinstalen para comprobar persistencia: desinstalar normalmente elimina el almacenamiento de la app.

### Pruebas automatizadas y sus límites

ValidacionesTest comprueba fechas, valores opcionales, números, formatos y algunas restricciones por rol. AlertasEventoTest cubre límites de ventana, fechas inválidas, estados terminados y cambio de año. ExampleUnitTest es una prueba de plantilla: no demuestra el negocio.

Una versión anterior compiló y pasó las cuatro pruebas de ValidacionesTest. Después hubo reorganización y alertas nuevas. **Las pruebas nuevas de alertas no se ejecutaron en esta sesión por falta de autorización.** Tener un archivo de prueba no significa que haya pasado. Verifiquen la versión actual en Android Studio antes de presentar.

## 14. Encontrar errores

| Síntoma | Revisar en orden |
| --- | --- |
| Campo no permite escribir | enabled, callback, clave en cambiar, estado publicado |
| Dato cambia pero no se guarda | validación, conversión, Repository, DAO |
| Se guarda pero no aparece | rol/responsable, filtros, observación Flow, pantalla |
| Error rojo incorrecto | clave del mapa, mensaje recibido por Campo, supportingText |
| Detalle antiguo | id, ON_RESUME, consulta actualizada |
| Contacto equivocado | organizacionId elegido, contactoId y pertenencia verificada por Repository |
| Alerta incorrecta | fecha ISO, estado, hoy y límite |
| Fallo de base actualizada | versión, migración, mensaje de esquema de Room |

Usen ir a declaración y buscar referencias. Los números de línea cambian al comentar; los nombres de funciones son mejores puntos de entrada.

Un breakpoint en guardar permite observar el estado antes/después de validar. Primero predigan el valor; después compruébenlo. Eso enseña más que detenerse sin una pregunta concreta.

Lean la primera causa útil del error. Un aviso de actualizar Gradle no es un error de Kotlin. AccessDeniedException en archivos generados corresponde a acceso/limpieza de archivos, no a una validación de formulario. No cambien dependencias, permisos y lógica simultáneamente.

## 15. Mejorar el código

### Primero estabilizar y entender

1. Completar el recorrido manual y registrar problemas reproducibles.
2. Revisar sangrías restantes, sobre todo condiciones sin llaves en seguimiento/catálogos. Usar bloques claros y comprobar el diff para no modificar accidentalmente el alcance de un if.
3. Retirar comentarios repetidos o imprecisos cuando entiendan la función. Mucho comentario no garantiza legibilidad; debe describir decisiones vigentes.
4. Revisar el mapa errores de CrearUiState y las claves de cambiar en CrearViewModel. En la revisión del 18/10/2026 se retiró errorNombre porque ya no tenía llamadas. Confirmar usos antes de retirar otros métodos.

### Requisitos de evaluación pendientes

| Pendiente | Por qué importa | Primer paso |
| --- | --- | --- |
| Usuarios Room y estructura normalizada | Implementados en v3 | Probar migración en dispositivo y explicar dependencias |
| IDs de organización/contacto | Implementados en v3 | Probar homónimos y consultas por JOIN |
| Pendientes y atrasados | Implementados en v4 con resolución e historial | Ejecutar el recorrido manual y las pruebas Room en Android |
| Filtros adicionales | Listado actual ofrece nombre y dos estados concretos | Revisar filtros exigidos y sus combinaciones |
| Cámara | Captura, preview y evidencia persistente | Botón en Detalle con TakePicture/FileProvider |
| Calendario | Recurso nativo exigido | Definir fechas/horas de evento y seguimiento |
| Animaciones | Tres interacciones, dos mecanismos | Elegir respuestas visuales útiles |
| Entrega colaborativa | Participación de ambos y defensa | Commits pequeños, README, preparación AVA |

Organizaciones/contactos hoy se crean y consultan; no se editan. Revisen si requieren edición para su entrega. Los colores de tarjetas ya están centralizados: no mantengan esa tarea como pendiente por copiar una lista antigua.

Para la cámara, la ubicación acordada es **Detalle de una oportunidad guardada**. La foto debe asociarse a su id y persistir como archivo, con su referencia en Room. El ejemplo de clase en caché no garantiza conservación permanente. Esta guía explica el plan; la cámara no está implementada.

### Mejoras técnicas concretas

- **Claves de texto:** reemplazarlas por enum o funciones explícitas reduce errores tipográficos. Mantener varias correspondencias exige cuidado.
- **Lecturas de catálogo:** ya pasan por CatalogoRepository; mantener esa separación al añadir operaciones.
- **Validación repetida:** compartir reglas entre ViewModel y Repository evita que cambien en un sitio y no en otro. La autorización al guardar sigue siendo necesaria.
- **Costo:** hoy se guarda como texto y se valida con Double. Si usarán CLP entero, pueden considerar pesos enteros; definir formato y migración antes de cambiarlo.
- **Resultados de operación:** separar éxito/error como estados explícitos permite mostrar colores y mensajes apropiados sin adivinar a partir de una cadena.
- **Errores de consulta:** los catálogos con stateIn no tienen el mismo manejo de errores de lectura que el listado. Revisar estados de fallo y reintento.
- **Transiciones:** confirmar con el profesor qué acciones permite cada rol en cada estado, no solo confirmar/descartar.

Elijan una mejora, expliquen el resultado esperado, modifiquen y prueben. No refactoricen todas las capas mientras agregan cámara y migraciones al mismo tiempo.

## 16. Ejercicios

### A. Seguir el nombre sin programar

Una persona escribe y la otra señala propiedad de estado, lectura valor, Campo, cambiar y copy. Después intercambien con descripción.

**Se completa cuando:** ambos explican por qué escribir no guarda en Room en cada tecla.

### B. Cambiar una validación

En una rama de trabajo cambien el máximo del nombre de 120 a 80. Mantengan coherente condición/mensaje y prueben 80/81 caracteres. Añadan un caso unitario.

**No alcanza:** cambiar solo el mensaje conservando la condición en 120.

### C. Modificar la ventana de alerta

Cambien de siete a tres días y actualicen las pruebas dependientes. Comprueben hoy, tres y cuatro días.

**Pregunta:** ¿hay que cambiar DAO, esquema o formato visible? No; se está modificando la regla de proximidad.

### D. Demostrar permisos

Admin crea y asigna a ejecutivo1. Entren con ejecutivo2 y expliquen por qué no aparece. Señalen qué método debe impedir consultar directamente ese id. Busquen también el bloqueo de confirmar/descartar.

**Se completa cuando:** identifican autorización en Repository además de botones ocultos.

### E. Diseñar la normalización

Dibujen Usuario, Organización, Contacto, Oportunidad y Seguimiento. Marquen claves primarias/foráneas. Inventen dos organizaciones con el mismo nombre y expliquen por qué elegir por nombre falla.

**Comparen con la v3:** localicen sus tablas y discutan cómo se conservan los datos heredados durante la migración.

### F. Explicar una transacción

Señalen las dos escrituras de cambiarEstado. Expliquen qué incoherencia aparece si solo se confirma una. Diseñen una prueba de fallo sobre una base de prueba, separada de los datos de presentación.

### G. Añadir un campo pequeño

Propongan un campo opcional y escriban la lista de lugares a modificar antes de programar. Distingan propiedad de pantalla, validación, entidad, migración, guardado y detalle.

**Se completa cuando:** pueden justificar qué cambios son necesarios y cuáles no para ese campo.

### H. Revisar comentarios

Cada uno elige cinco comentarios de código que no escribió. Debe explicarlos con un ejemplo y detectar si describen lo que realmente hace la función. Si el comentario y el código difieren, registren el problema antes de corregirlo.

## 17. Preguntas de defensa

Respondan primero sin leer la columna derecha.

| Pregunta | Qué debe contener la respuesta |
| --- | --- |
| ¿Por qué Screen, UiState y ViewModel? | Presentación, representación del estado y coordinación separadas |
| ¿Qué hace copy? | Otro objeto, cambios indicados, conserva valores restantes |
| ¿StateFlow guarda en disco? | No; comunica estado en memoria, Room persiste |
| ¿Por qué Crear no llama a ListaViewModel? | La fuente compartida observable es Room |
| ¿Qué hace suspend? | Suspender/reanudar, sin elegir automáticamente un hilo |
| ¿Para qué Repository si hay DAO? | Operaciones/reglas/autorización frente a SQL específico |
| ¿Cómo se dibuja el rojo? | Mapa, clave, Campo, isError, supportingText |
| ¿Crear y Editar cómo se distinguen? | Id nuevo/existente, precarga, Insert/Update |
| ¿Qué ocurre al fallar guardar? | Mensaje, indicador desactivado, datos conservados |
| ¿Cómo se mantiene historial? | Filas relacionadas de Seguimiento, sin reemplazar notas anteriores |
| ¿Qué asegura withTransaction? | Escrituras relacionadas confirmadas/revertidas juntas |
| ¿Por qué ISO en Room? | Orden del texto coincide con fechas; UI usa otro formato |
| ¿Null o cero asistentes? | Desconocido frente a valor informado |
| ¿Cómo justifican la normalización v3? | Usuario y catálogos se referencian por IDs; los JOIN presentan etiquetas sin duplicarlas en disco |
| ¿La cámara ya está? | No, está planificada en Detalle |
| ¿Ocultar un botón autoriza? | No; Repository debe comprobar la operación |
| ¿Qué pruebas pasaron? | Distinguir versión verificada previamente de pruebas nuevas pendientes |
| ¿Qué hace un índice? | Ayuda consultas; no hace único un nombre salvo restricción única explícita |
| ¿Quién genera las implementaciones DAO? | Room durante compilación; no se editan a mano |

Una buena respuesta usa el código actual, un ejemplo y una limitación cuando corresponda. Eviten decir «porque lo hizo la IA» o «porque es MVVM» sin poder explicar la responsabilidad y el recorrido.

Si les piden modificar algo, primero nombren la capa responsable y el comportamiento que esperan. Después cambien. Eso demuestra comprensión mejor que localizar una línea de memoria.

## 18. Plan de estudio

| Sesión | Trabajo conjunto | Evidencia |
| --- | --- | --- |
| 1 | Negocio, pantallas, navegación | Dibujar las rutas sin guía |
| 2 | Estado, Campo y cambiar | Seguir dos campos completos |
| 3 | Validaciones y guardado | Provocar y explicar errores |
| 4 | Entity, DAO, Repository, migración | Explicar tablas y una escritura |
| 5 | Detalle, seguimiento, permisos | Historial y prueba con dos usuarios |
| 6 | Alertas y tests | Límites y una mejora pequeña |
| 7 | Simulación de defensa | Cada uno explica/modifica algo que no escribió |

Para cada sesión anoten:

```text
Fecha:
Qué revisamos:
Archivo y función principal:
Qué creíamos que ocurría:
Qué comprobamos:
Qué no entendimos todavía:
Cambio realizado y motivo:
Prueba realizada y resultado:
Próximo paso:
```

Conserven una lista de funciones comprobadas y otra de pendientes. Antes de tocar archivos compartidos acuerden quién los modifica y cómo integrar. No basta conocer la propia pantalla: ambos deberían seguir un guardado desde el botón hasta Room y de regreso al listado.

### Criterio para decidir que entendieron una parte

Pueden explicarla sin leer los comentarios, localizarla en Android Studio, predecir un caso correcto y uno incorrecto, modificar una regla pequeña y verificar el resultado. Si todavía solo pueden repetir el comentario, vuelvan al ejemplo y al flujo del dato.


### Verificación más reciente del punto 2

APK generado y 19 pruebas unitarias aprobadas. Pruebas de Room compiladas, pendientes de ejecución en dispositivo. Este resultado reemplaza los límites históricos descritos antes para esas mismas comprobaciones.
