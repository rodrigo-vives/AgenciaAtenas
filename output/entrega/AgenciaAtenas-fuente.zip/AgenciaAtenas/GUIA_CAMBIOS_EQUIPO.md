> Actualización: se retiraron las migraciones históricas para simplificar la entrega. Room crea directamente las tablas actuales. Se mantiene la versión 4 para conservar las instalaciones que ya usan esa estructura. Solo las bases anteriores necesitan borrar datos o reinstalar la aplicación. Las explicaciones de migraciones que aparecen más abajo son históricas y ya no describen código vigente.

> Actualización del punto 2: la base está en versión 4. Ver [PENDIENTES_Y_RECORDATORIOS.md](PENDIENTES_Y_RECORDATORIOS.md) para pendientes, atrasados y resolución de tareas. Los apartados siguientes conservan el registro histórico de cambios.

> Actualización: la base está en versión 3. Los apartados que describen copias y cuentas en memoria documentan la entrega anterior. Para el estado actual y las pruebas pendientes, leer [NORMALIZACION_BASE_DATOS.md](NORMALIZACION_BASE_DATOS.md).

# Guía de cambios para continuar en equipo

## Alcance de esta entrega

Se completa el flujo inicial de creación, edición, detalle y seguimiento, y se organiza
la navegación en nueve pantallas: Login, Inicio/Dashboard, Lista, Crear/Editar,
Detalle, Organizaciones, Contactos, Seguimiento y Panel de supervisor.
Crear y Editar comparten pantalla. El ejecutivo no tiene acceso al panel de supervisor.
No se presenta esta entrega como cumplimiento completo del checklist.

## Cómo recorrer y presentar el trabajo

1. Ejecutar la app con Android Studio. La base se actualiza de versión 1 a 2 sin borrarla.
2. Entrar con `admin`, contraseña `1234` (supervisor), o con `ejecutivo1`,
   `ejecutivo2`, `ejecutivo3`, todos con `1234` (ejecutivos ficticios).
3. Desde Inicio, registrar una organización y un contacto asociado. Solo el nombre de
   organización es obligatorio; contacto requiere nombre y organización. Correo y teléfono
   pueden quedar vacíos, pero si se completan deben tener formato válido.
4. Abrir Oportunidades y crear una. Completar nombre, tipo, fecha de detección,
   fecha de inicio, comuna, región y público esperado. Seleccionar prioridad.
   Fechas visibles: DD/MM/AAAA. Ejemplo ficticio: Feria de prueba, 20/10/2026.
5. Elegir organización y contacto. Son opcionales porque puede detectarse una oportunidad
   antes de conocer al organizador. Si no hay catálogos, volver a Inicio y registrarlos antes.
   Volver atrás abandona el formulario sin guardar; todavía no hay borrador persistente.
6. Guardar: abre Detalle después de que Room confirme la escritura.
7. Editar desde Detalle y volver. Comprobar que muestra los datos nuevos.
8. Abrir Seguimiento; registrar acción y resultado. Próxima acción y fecha son opcionales,
   pero deben completarse juntas. Cada gestión se conserva como un registro separado.
9. Cambiar estado desde Detalle: también se registra en el historial.
10. Con admin, abrir Panel de supervisor y asignar/reasignar a un ejecutivo.
    Entrar con ese ejecutivo: solo debe ver y gestionar sus oportunidades asignadas.
11. Cerrar completamente y volver a abrir la app; comprobar persistencia y entrar nuevamente.

## Cambios y por qué

- CrearUiState conserva los datos escritos por el estudiante. Añade mapa de errores,
  estado de carga/guardado e identificador de edición.
- CrearViewModel usa AndroidViewModel, Repository y Room como el ejemplo de clase.
  La función cambiar(clave, valor) sustituye muchas funciones casi idénticas; cada rama
  sigue usando copy explícito, sin reflexión. CamposFormulario describe etiquetas y lectura.
- CrearScreen reutiliza un formulario para crear y editar. La organización y el contacto
  se seleccionan de catálogos; el responsable viene de la sesión.
- Validaciones y Fechas están en utils. No se guarda si hay errores; los valores se conservan.
  Fechas se almacenan como AAAA-MM-DD para mantener orden cronológico por texto.
  Asistentes desconocidos se guardan como null; cero significa explícitamente cero.
  El costo, si se conoce, se introduce como número no negativo en CLP.
- Detalle muestra los datos completos. Al regresar de Editar recarga la información.
- Seguimiento tiene tabla propia y clave foránea a oportunidad. Estados y asignaciones
  registran historial dentro de transacciones para que ambos cambios se guarden juntos.
- Organizaciones y contactos tienen pantallas de registro/consulta y relación por ID.
- OportunidadRepository aplica alcance por responsable y permisos de cambios de estado.
  Las transiciones son una propuesta inicial explícita en estadosPermitidos; validarlas
  con el profesor. Solo admin confirma/descarta; cerrado no permite otra transición.
- SesionActual conserva sesión solo en memoria: al reiniciar se requiere login.
  Login permite cuatro cuentas ficticias. Son un puente: falta UsuarioEntity en Room.
- ListaViewModel usa Repository; ListaScreen muestra fechas DD/MM/AAAA y errores de lectura.
- AppDatabase versión 2 incluye migración explícita que conserva los datos de versión 1.
  No borrar datos ni desinstalar para actualizar una instalación con registros importantes.

## Decisión temporal de integración con el trabajo del compañero

GestionOportunidadEntity sigue incluyendo una copia de nombres de organización y contacto.
Se mantiene para presentar este avance sin sustituir toda la capa original de datos.
Por eso la base NO cumple todavía 3FN: falta reemplazar esas copias por organizacionId,
contactoId y responsableId; crear UsuarioEntity; adaptar consultas, modelos y migración.
Seleccionar catálogos actualmente copia datos a la oportunidad. Cambios posteriores en el
catálogo no se reflejan automáticamente en esa copia. Nombres repetidos de organizaciones
pueden hacer ambiguo el filtrado de contactos; al normalizar, seleccionar siempre por ID.
Los registros antiguos se conservan en oportunidades, pero no generan catálogos automáticamente.
Si tenían fechas fuera de ISO deben corregirse al editar antes de confiar en su orden.

## Pendientes del checklist para acordar entre ambos

- Normalización completa 3FN y usuarios persistidos con claves foráneas.
- Cámara, archivos persistentes, evidencias fotográficas y calendario del dispositivo.
- Tres interacciones animadas mediante al menos dos mecanismos.
- Colores de tarjetas: ya centralizados en ui/theme/Color.kt; revisar consistencia del resto.
- Dashboard de seguimientos pendientes/atrasados y propuestas sin respuesta.
  Inicio solo muestra total y los tres eventos futuros más cercanos por ahora.
- Completar filtros del PDF/checklist y revisar las reglas de transición con el profesor.
- Agregar edición de catálogos si la pauta de entrega lo exige; hoy registran y consultan.
- Confirmaciones visuales de guardado más visibles, aviso de cambios sin guardar e íconos.
- Pruebas en emulador/teléfono de navegación, persistencia, permisos y migración Room real.
- GitHub con participación de ambos, README definitivo y entrega AVA.

## Cómo leer los comentarios

Buscar CAMBIO para conocer la intención de una modificación, COMPATIBILIDAD para puentes
con el proyecto anterior y PENDIENTE para trabajo que falta. No se comentan cada llave
ni cada línea repetida: los comentarios explican decisiones y responsabilidades.

## Verificación

Las pruebas ValidacionesTest cubren fechas reales y bisiestos, datos opcionales,
coherencia de fechas, valores numéricos, correo/teléfono y restricción de confirmación
al ejecutivo. La migración SQL se comprueba con una fila sintética y claves foráneas.
La compilación y las pruebas locales se ejecutan con Gradle; la revisión visual y
el recorrido en un dispositivo deben realizarse también antes de presentar.

### Resultado de verificación de esta entrega

El código compiló y las pruebas pasaron durante la verificación. La ejecución habitual en Android Studio sigue pendiente de comprobar. Se retiró el script de verificación y se restauró la configuración desde el respaldo, conservando el código nuevo.

## Organización para estudiar el código

Esta revisión solo organiza y comenta el código; no agrega funcionalidades.

1. Abrir Navegacion.kt: muestra las rutas y los callbacks que conectan pantallas.
2. Leer CrearUiState.kt, CrearScreen.kt y CrearViewModel.kt, en ese orden.
3. Consultar ComponentesFormulario.kt para entender Pagina, Campo y Selector.
4. Consultar CamposFormulario.kt para entender las claves y etiquetas del formulario.
5. Leer ValidarOportunidad.kt y Validaciones.kt para seguir los errores y las fechas.
6. Leer OportunidadRepository.kt, OportunidadDao.kt y AppDatabase.kt para seguir el guardado.
7. Repetir el recorrido con Detalle, Seguimiento y los catálogos.

Se separaron DetalleUiState, CatalogoUiState e InicioUiState de sus ViewModels.
SeguimientoScreen y SupervisorScreen tienen archivos propios. Las entidades
OrganizacionEntity, ContactoEntity y SeguimientoEntity y CatalogoDao también se
separaron del antiguo Catalogos.kt. Las transiciones están en ReglasEstadoOportunidad.kt.
Los nombres de clases, tablas y rutas siguen siendo los mismos.

Los comentarios explican decisiones: copy conserva otros campos, StateFlow comunica
cambios, Repository autoriza operaciones y Room persiste los datos. Las advertencias
sobre compatibilidad y 3FN siguen vigentes; reorganizar archivos no normaliza la base.

## Alerta del listado solicitada en el Word

ListaScreen ahora indica Evento hoy, Evento mañana o Evento en N días, desde hoy
hasta siete días inclusive. La ventana de siete días es una decisión del proyecto,
porque el Word no define cuántos días son próximos. AlertasEvento.kt calcula la
proximidad a partir de la fecha ISO y omite eventos pasados, descartados, realizados
o cerrados. Si no hay alerta se conserva el color por estado anterior.
Los colores de tarjetas están centralizados en ui/theme/Color.kt y el texto mantiene
contraste en modo oscuro. No se solicitan permisos ni se generan notificaciones.
La fecha se actualiza al volver a primer plano; no hay un temporizador de medianoche.
Las pruebas AlertasEventoTest cubren límites, fechas inválidas, estados y cambio de año.


## Guía de estudio ampliada

Para estudiar el flujo, practicar en pareja y preparar la defensa, leer [GUIA_ESTUDIO_AGENCIA_ATENAS.md](GUIA_ESTUDIO_AGENCIA_ATENAS.md). Este archivo conserva el registro de cambios; la guía nueva desarrolla conceptos, ejercicios y mejoras.


## Selector de estados más directo

Se retiró la secuencia rígida de cambios comerciales. Ahora se puede saltar entre los
estados de gestión, por ejemplo de Contacto pendiente a Propuesta enviada, sin registrar
acciones intermedias ficticias. Confirmar/descartar sigue reservado al supervisor.
Activación realizada requiere confirmación previa; Cerrado no permite cambios.
UI y Repository consultan la misma función estadosPermitidos y se conserva el historial
transaccional de cada cambio real. TransicionesEstadoTest comprueba estas restricciones.
