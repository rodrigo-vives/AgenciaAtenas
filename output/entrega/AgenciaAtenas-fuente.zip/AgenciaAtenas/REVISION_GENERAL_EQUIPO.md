> Actualización base 5 (18/10/2026): para el estado vigente consultar CUMPLIMIENTO_REQUISITOS.md y GUIA_COMPLEMENTOS_CASO.md. Este documento conserva la revisión anterior y puede mencionar limitaciones ya resueltas.

# Revisión general para el equipo

Revisión del 18/10/2026. Objetivo: que el equipo pueda leer, explicar y modificar el proyecto sin memorizar fragmentos aislados. Los comentarios se concentran en las decisiones, los pasos que pueden resultar nuevos y el recorrido de los datos.

## Qué se revisó y cambió

Se recorrieron las carpetas data, ui, utils, theme, las pruebas y las guías. Se contrastó el enfoque con los seis PPT locales del profesor. Se mantuvo el esquema de base versión 4, los nombres de las tablas y los destinos de navegación.

- Navegacion.kt: parámetros con nombre, callbacks breves, bloques ordenados y explicación de cómo viaja el ID y se limpia la pila al cerrar sesión. Conserva las mismas rutas.
- ValidarCatalogo.kt: se extrajeron las reglas que estaban dentro de CatalogoViewModel. El ViewModel ahora pide validar, publica errores y coordina el guardado. El Repository conserva su comprobación antes de escribir.
- Imagenes.kt: lectura, reducción de tamaño y orientación de la fotografía, separadas del Composable. Un archivo ilegible produce un mensaje en vez de propagar una excepción a la pantalla.
- RecursosOportunidad.kt: conserva botones, lanzamiento de cámara, contador y animaciones. La lectura pesada se espera en Dispatchers.IO mediante la función anterior.
- MainActivity, DAO, Repository y ViewModels: comentarios sobre entrada de la aplicación, JOIN, IDs, Flow, identidad vigente, transacciones y resolución de próximas acciones.
- ValidarOportunidad.kt: se cambió el parámetro abreviado s por estado. Se corrigió el horario cuando no se escribe fecha final: se interpreta como el mismo día, igual que Calendar.
- Validaciones.kt y ValidarSeguimiento.kt: bloques explícitos y variables intermedias para seguir los pasos. Se retiraron las conversiones forzadas con !! al leer fechas y se evita aceptar parcialmente una fecha ISO con caracteres sobrantes.
- CrearUiState: se retiró errorNombre, que ya no se usaba; los mensajes se conservan en errores por campo.
- ListaViewModel: se retiraron métodos antiguos sin llamadas y se desplegaron eventos de filtros para facilitar su lectura.
- LoginScreen: el contenido se puede desplazar con teclado o fuente grande.
- LoginViewModel: registra la causa técnica de un fallo de base en Logcat, sin registrar usuario/contraseña ingresados.
- Theme y Converters: se quitaron fragmentos de plantilla sin uso y se sustituyeron por explicaciones de lo que realmente se ejecuta.

## Relación con los PPT

| Material del profesor | Qué sigue el proyecto | Adaptación que el equipo debe conocer |
| --- | --- | --- |
| 01-De Kotlin a Android | Clases, funciones, colecciones y corrutinas básicas | El caso tiene varias entidades y roles |
| 02-Compose | Funciones Composable, campos, botones y componentes de diseño | Campo, Selector y Pagina reutilizan presentación |
| 03-Navigation, diapositivas 31-33 y 45 | rememberNavController, NavHost, rutas y callbacks, popBackStack | Se pasa ID y hay parámetro opcional de tarea; salir limpia la pila |
| 04-Validaciones, diapositivas 17-26 | Separar Screen, ViewModel y funciones de validación | Mapa campo -> mensaje para múltiples errores, en vez de un Boolean por campo |
| 05-Persistencia, diapositivas 13-21, 30, 32, 35 y 47 | UiState + MutableStateFlow/asStateFlow/update, Repository, DAO, Room y AndroidViewModel | JOIN, claves foráneas, transacciones y alcance por usuario cubren la checklist relacional |
| 06-Recursos, diapositivas 13, 26-29 y 39-45 | AnimatedVisibility, Crossfade, TakePicture y FileProvider | Archivos persistentes en vez de caché; vista previa con BitmapFactory en vez de Coil; ampliación y control de cancelación |

El proyecto sigue el método de separación de responsabilidades, no una copia literal de los ejemplos. El PPT 06 ya advierte que la caché no garantiza conservar fotos importantes. Se usa filesDir porque la evaluación exige evidencias persistentes. No se agregó Coil ni otra dependencia para este ajuste.

Calendar mediante ACTION_INSERT responde a la checklist. No se presenta como una implementación copiada de una diapositiva. SavedStateHandle, la orientación EXIF y la transacción de resolución son ampliaciones que se explican por la rotación, las fotografías reales y la coherencia de los datos.

## Cómo leer el proyecto sin perderse

1. Abrir MainActivity.kt y Navegacion.kt: ubicar por dónde entra la app y qué pantalla corresponde a cada ruta.
2. Leer LoginUiState, LoginViewModel y LoginScreen: ver cómo un campo envía un evento y recibe un estado nuevo.
3. Seguir UsuarioRepository -> UsuarioDao -> UsuarioEntity: encontrar de dónde sale la cuenta y su rol. SesionActual conserva identidad en memoria, no la base.
4. Repetir el recorrido con CrearScreen -> CrearViewModel -> validarOportunidad -> OportunidadRepository -> OportunidadDao.
5. Leer GestionOportunidadEntity y OportunidadDetalle: distinguir tabla guardada de resultado de JOIN para presentación.
6. Leer ListaUiState: identificar cada criterio y por qué se combinan con AND sobre datos ya autorizados.
7. Leer DetalleViewModel, SeguimientoEntity y registrar del Repository: distinguir acción realizada, próxima acción y resultado que completa una tarea.
8. Leer EvidenciaViewModel -> EvidenciaRepository y luego RecursosOportunidad/Imagenes: distinguir ruta, archivo, URI y bitmap.

Ejemplo: escribir Nombre NO guarda en Room. onValueChange llama cambiar, update publica un copy del UiState y Compose dibuja el valor nuevo. Guardar primero valida y después llama al Repository desde viewModelScope.launch. El DAO escribe y Room actualiza sus Flow. El ID guardado permite abrir el detalle.

## Palabras que aparecen en los comentarios

- val: referencia de solo lectura; no equivale a guardar algo en disco.
- copy: genera un nuevo estado conservando las propiedades que no se reemplazan.
- it: nombre implícito del parámetro de una lambda; se prefieren nombres explícitos cuando hay bloques anidados.
- ?: valor: usa ese valor si lo de la izquierda es null.
- ?. : accede solo si el objeto existe; evita forzar un valor que puede faltar.
- suspend: función que puede suspenderse; no crea por sí misma un hilo de trabajo.
- Flow: consulta observable que puede emitir más de un resultado.
- StateFlow: flujo que conserva el estado actual que lee la pantalla.
- stateIn: convierte una consulta Flow en estado observable dentro del alcance del ViewModel.
- combine: reúne los últimos valores de dos flujos y recalcula al cambiar cualquiera.
- withTransaction: confirma todas las escrituras del bloque o revierte el conjunto al fallar.
- UUID: nombre único para no sobrescribir una captura anterior.

## Comprobación de entrega

El resultado de las herramientas se actualiza al finalizar esta revisión. Es necesario distinguir cuatro cosas: compilar, aprobar pruebas unitarias, ejecutar pruebas de Room en Android y comprobar visualmente pantallas/cámara/calendario. Una no sustituye a las otras.

Para la defensa ambos deben poder crear una oportunidad, seguir sus valores por las capas, explicar los permisos y cambiar una regla sencilla. Los comentarios ayudan, pero la demostración individual requiere practicar los recorridos de REVISION_Y_ENTREGA.md.

Los pendientes de la entrega anterior se conservan: nombres y sección del equipo, repositorio compartido y commits reales, guardado real en Calendar con una cuenta configurada, pruebas instrumentales y recorridos de UI. El historial separado por contacto y un formulario específico de resultados no se añadieron dentro de esta revisión de legibilidad; se mantienen señalados como alcance parcial del PDF.

No se cambiaron versiones de Gradle/dependencias, atributos de carpetas, migraciones ni estructura de Room. Las oportunidades y fotografías existentes usan la misma estructura.

## Resultado de las herramientas

- APK de depuración generado correctamente.
- 36 pruebas unitarias aprobadas, cero fallos y cero errores; seis pruebas nuevas cubren catálogos y coherencia de horario.
- Pruebas instrumentales compiladas, sin ejecutar por falta de dispositivo conectado por ADB.
- Lint terminó sin errores, con 14 advertencias de mantenimiento. No se actualizaron librerías para ocultarlas.
- ZIP fuente actualizado y comprobado como archivo válido; no incluye datos del emulador ni cachés.

El código queda organizado para estudiar y realizar la demostración. La aprobación académica depende además de comprobar los recorridos, completar las evidencias y explicar el alcance parcial del PDF señalado en REVISION_Y_ENTREGA.md.
