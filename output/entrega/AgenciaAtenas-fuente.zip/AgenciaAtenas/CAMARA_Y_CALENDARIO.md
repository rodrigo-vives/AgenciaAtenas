# Cámara y calendario - guía del punto 3

## Dónde se encuentran

Abre una oportunidad guardada desde el listado. En su detalle aparecen Fotografías de la oportunidad y Calendario del dispositivo. Ambos roles pueden usar estas funciones en las oportunidades a las que tienen acceso.

Se eligió el detalle porque la oportunidad ya tiene un ID definitivo. No hace falta tomar fotos antes de guardar el formulario ni resolver qué hacer con las de una oportunidad que se cancela.

## Cámara: recorrido completo

1. El botón pide a EvidenciaViewModel preparar una captura.
2. EvidenciaRepository consulta la oportunidad en Room. Así comprueba existencia y permiso con las reglas actuales del usuario.
3. Crea un archivo vacío con un nombre UUID en `filesDir/evidencias/ID/`. Cada oportunidad tiene su propia carpeta.
4. El archivo usa extensión `.pending` mientras la captura no está confirmada. Las consultas de fotografías solo incluyen `.jpg` terminados.
5. FileProvider convierte su ruta privada en un URI `content://`. La cámara externa puede escribir en él con un permiso temporal concedido por TakePicture.
6. TakePicture abre la cámara del dispositivo. No se usa una cámara integrada ni se solicita CAMERA, porque la captura la realiza otra aplicación.
7. Si la cámara devuelve éxito y el archivo tiene contenido, Repository vuelve a comprobar acceso y lo renombra a `.jpg`. Si se cancela, elimina el archivo pendiente.
8. El ViewModel publica la lista y Compose muestra la vista previa.

La carpeta privada persiste al cerrar la aplicación o reiniciar el dispositivo. Borrar almacenamiento o desinstalar elimina estas fotos igual que los registros locales. No se guardan automáticamente en la galería ni se envían por internet.

### Por qué no agregamos una columna a Room

La asociación es la carpeta nombrada con el ID de la oportunidad. No se duplican nombres ni se almacena el bitmap en SQLite. Es una solución sencilla para este proyecto: no cambia el esquema ni la versión de la base.

Si en el futuro se requieren títulos, autores, fechas consultables o sincronización de evidencias, convendría una entidad Evidencia con clave foránea. Actualmente no hay eliminación de oportunidades; si se añade, también habrá que eliminar sus archivos asociados.

### Rotación, memoria y cancelaciones

SavedStateHandle conserva ruta e ID de la captura pendiente si Android recrea el destino mientras la cámara está abierta. No guarda la foto en memoria: conserva cómo encontrarla.

La previsualización lee primero las dimensiones y decodifica una imagen reducida fuera del hilo principal. Aplica el giro EXIF para respetar la orientación de la cámara. No modifica el archivo original.

Si no hay cámara disponible se muestra un mensaje y se elimina el archivo preparado. Una cancelación normal tampoco reemplaza ni borra fotos anteriores. Si se fuerza la detención del proceso y nunca vuelve un resultado, puede quedar un `.pending` que no se mostrará como evidencia; no se implementó un servicio de limpieza de archivos abandonados.

## Calendario: recorrido completo

1. El botón toma el nombre, descripción, ubicación, fechas y horario de la oportunidad guardada.
2. intervaloCalendario convierte fechas ISO a milisegundos y comprueba coherencia.
3. Con horario se utiliza la zona horaria del dispositivo y las horas reales. Si falta fecha final, se usa la de inicio.
4. Sin horario se crea un evento de día completo. Su fecha final se envía como el día siguiente al último día incluido, en UTC, porque Calendar utiliza un límite final exclusivo.
5. ACTION_INSERT abre el editor del calendario con esos datos.
6. El usuario revisa y decide guardar o cancelar en esa aplicación.

No accedemos directamente a las tablas del calendario: por eso no se solicitan READ_CALENDAR ni WRITE_CALENDAR. Tampoco afirmamos que el evento quedó guardado por el simple hecho de abrir el editor. Algunas aplicaciones no devuelven una confirmación fiable; nuestra app muestra una indicación de revisión.

Si no hay una aplicación que atienda el intent, se informa sin cerrar Agencia Atenas. El emulador puede tener cámara pero carecer de calendario o de una cuenta/calendario configurado.

El botón exporta eventos. Los seguimientos mantienen los recordatorios internos del punto 2; no se añadió otro botón de exportación para ellos. Pulsar varias veces y guardar varias veces en Calendar puede crear eventos duplicados: no hay sincronización ni vínculo persistido con el evento externo.

## Qué hace cada archivo

- `data/EvidenciaRepository.kt`: comprueba permisos con OportunidadRepository y gestiona archivos en el hilo de entrada/salida.
- `ui/EvidenciaViewModel.kt`: estado mediante StateFlow, ruta pendiente mediante SavedStateHandle y coordinación de operaciones.
- `ui/RecursosOportunidad.kt`: botones, contrato TakePicture, vista previa y apertura del calendario. Los intents pertenecen a la UI porque abren aplicaciones externas.
- `utils/Imagenes.kt`: lectura y orientación EXIF separadas de la presentación desde la revisión del 18/10/2026.
- `utils/FechasCalendario.kt`: conversión y validación de fechas separada de Compose y verificable con pruebas unitarias.
- `ui/DetalleScreen.kt`: incorpora el bloque a la oportunidad autorizada.
- `AndroidManifest.xml`: declara FileProvider privado y acceso temporal por URI.
- `res/xml/rutas_evidencias.xml`: limita lo compartido a la carpeta de evidencias.
- `FechasCalendarioTest.kt`: comprueba días completos, cambio de año, zona horaria, cruce de medianoche y datos inválidos.

Los archivos nuevos contienen comentarios sobre el recorrido y las decisiones. No se añadieron dependencias ni se modificaron opciones de Gradle ni el esquema de Room.

## Cómo probar entre ambos

1. Abrir una oportunidad, tomar una foto y confirmarla en la cámara. Debe aparecer la vista previa.
2. Tomar una segunda foto. Ambas deben conservarse.
3. Abrir la cámara y cancelar: no debe añadirse una foto vacía ni desaparecer la anterior.
4. Cerrar y volver a abrir la aplicación, entrar y abrir la oportunidad: las fotos deben seguir.
5. Abrir otra oportunidad: no debe mostrar las fotos de la primera.
6. Verificar que un ejecutivo sin acceso no puede abrir ese detalle y que el nuevo responsable conserva las evidencias al reasignar.
7. Abrir la cámara y rotar el dispositivo antes de confirmar. Verificar que el resultado vuelve a la oportunidad correcta.
8. En una oportunidad con horario, abrir Calendar y revisar título, ubicación y fechas/horas antes de guardar.
9. Repetir con un evento sin horario: debe mostrarse como día completo, incluyendo la fecha de término.
10. Cancelar el editor del calendario: Agencia Atenas sigue funcionando y no informa falsamente que guardó el evento.
11. Guardar un evento y comprobarlo desde el calendario del dispositivo.

Las pruebas unitarias no sustituyen este recorrido real de cámara/calendario. No se detectó un dispositivo conectado por ADB durante esta implementación; la interacción con aplicaciones externas queda pendiente de comprobación manual.

## Referencia técnica

Se utilizan los intents nativos documentados por Android: https://developer.android.com/guide/components/intents-common

## Verificación de esta implementación

- APK de depuración compilado correctamente.
- 25 pruebas unitarias aprobadas, incluidas las 6 nuevas de calendario.
- Pruebas instrumentales compiladas; no ejecutadas al no detectarse un dispositivo conectado.
- Falta confirmar manualmente captura, cancelación, persistencia visual y guardado en Calendar en el dispositivo de ustedes.
